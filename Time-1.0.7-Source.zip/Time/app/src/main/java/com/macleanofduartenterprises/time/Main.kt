package com.macleanofduartenterprises.time

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.*
import android.text.InputType
import android.net.Uri
import java.io.File
import java.time.*
import java.time.format.DateTimeFormatter

class Main:Activity(){
    lateinit var db:Store
    lateinit var guard:Guard
    lateinit var bells:Bells
    val prefs by lazy{getSharedPreferences("display",0)}
    var visible=false
        private set
    var page="Clock"
    var tool="Clock"
    var jobsTab=false
    lateinit var sheet:LinearLayout
    lateinit var shell:LinearLayout
    var tick:(()->Unit)?=null
    private val handler=Handler(Looper.getMainLooper())
    private var ringLabel:String?=null
    private val ticker=object:Runnable{override fun run(){
        val ring=getSharedPreferences("ring",0).getString("label",null)
        if(ring!=ringLabel){ringLabel=ring;draw()}else tick?.invoke()
        handler.postDelayed(this,350)
    }}
    var dialog:AlertDialog?=null
    var pendingFile:String?=null
    var from:LocalDate=LocalDate.now().with(java.time.DayOfWeek.MONDAY)
    var to:LocalDate=from.plusDays(6)
    var appearance=Appearance()
    var dark=false
    val pine get()=if(dark)Color.rgb(153,220,195) else Color.rgb(22,62,56)
    val primary get()=if(dark)Color.rgb(35,94,77) else pine
    val ink get()=if(dark)Color.rgb(234,244,237) else Color.rgb(25,49,44)
    val muted get()=if(dark)Color.rgb(181,201,190) else Color.rgb(75,96,88)
    val cream get()=if(dark)Color.rgb(17,25,22) else Color.rgb(248,248,242)
    val secondary get()=if(dark)Color.rgb(43,60,52) else Color.rgb(228,237,229)
    val surface get()=if(dark)Color.rgb(30,41,35) else Color.WHITE
    override fun onCreate(state:Bundle?){
        guard=Guard(this);db=Store(this,guard)
        appearance=db.appearance()
        dark=appearance.night(resources.configuration.uiMode)
        setTheme(if(dark)android.R.style.Theme_Material_NoActionBar else android.R.style.Theme_Material_Light_NoActionBar)
        super.onCreate(state)
        AlarmMedia.channel(this)
        bells=Bells(this)
        page=OpeningPage.resolve(appearance.openingPage,lastMainPage(),state?.getString("page"),intent.getStringExtra("tool"))
        rememberPage()
        tool=state?.getString("tool")?:intent.getStringExtra("tool")?:"Clock"
        jobsTab=state?.getBoolean("jobsTab")?:false
        pendingFile=state?.getString("pending")
        state?.getString("from")?.let{from=LocalDate.parse(it)}
        state?.getString("to")?.let{to=LocalDate.parse(it)}
        draw()
    }
    override fun onNewIntent(i:Intent){super.onNewIntent(i);setIntent(i);i.getStringExtra("tool")?.let{tool=it;go("Clock")}}
    override fun onSaveInstanceState(b:Bundle){super.onSaveInstanceState(b);b.putString("page",page);b.putString("tool",tool);b.putString("pending",pendingFile);b.putBoolean("jobsTab",jobsTab);b.putString("from",from.toString());b.putString("to",to.toString())}
    override fun onResume(){
        super.onResume();draw();handler.post(ticker)
        if(Build.VERSION.SDK_INT>=33 && !prefs.getBoolean("askedNotifications",false) && !notificationsReady())
            enableNotifications(false)
    }
    override fun onRequestPermissionsResult(request:Int,permissions:Array<String>,results:IntArray){
        super.onRequestPermissionsResult(request,permissions,results)
        if(request==77)draw()
    }
    override fun onPause(){handler.removeCallbacks(ticker);super.onPause()}
    override fun onStart(){super.onStart();visible=true}
    override fun onStop(){visible=false;guard.leave();dialog?.dismiss();super.onStop()}
    override fun onDestroy(){db.close();super.onDestroy()}
    @Deprecated("Android back")
    override fun onBackPressed(){
        val last=lastMainPage()
        val home=OpeningPage.resolve(appearance.openingPage,last)
        when{
            page=="Admin"->go("Settings")
            page=="Settings"->go(last)
            page=="Clock" && tool!="Clock"->{tool="Clock";draw()}
            page!=home->go(home)
            else->finish()
        }
    }
    private fun lastMainPage()=prefs.getString("lastMainPage",null)?.takeIf{it in OpeningPage.tabs}?:"Clock"
    private fun rememberPage(){
        if(page in OpeningPage.tabs && lastMainPage()!=page)prefs.edit().putString("lastMainPage",page).apply()
    }
    fun go(next:String){if(next!="Admin")guard.leave();page=next;rememberPage();draw()}
    fun dp(n:Int)=(resources.displayMetrics.density*n+0.5f).toInt()
    fun padded(v:View,n:Int){val p=dp(n);v.setPadding(p,p,p,p)}
    fun bg(color:Int,r:Int=12)=GradientDrawable().apply{setColor(color);cornerRadius=dp(r).toFloat()}
    fun col(parent:LinearLayout?=null):LinearLayout=LinearLayout(this).apply{orientation=1;parent?.addView(this)}
    fun row(parent:LinearLayout)=LinearLayout(this).also{it.orientation=0;parent.addView(it)}
    fun label(parent:LinearLayout,text:String,size:Int=16,color:Int=ink,bold:Boolean=false):TextView=TextView(this).apply{
        this.text=text;textSize=size.toFloat();setTextColor(color);if(bold)setTypeface(Typeface.DEFAULT,Typeface.BOLD)
        setPadding(0,dp(4),0,dp(4));parent.addView(this)
    }
    fun heading(title:String){label(sheet,title,29,ink,true)}
    fun card(parent:LinearLayout=sheet):LinearLayout{
        val box=col();box.background=bg(surface);padded(box,16)
        parent.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,dp(7))});return box
    }
    fun action(parent:LinearLayout,text:String,primary:Boolean=false,fn:()->Unit):Button=Button(this).apply{
        this.text=text;isAllCaps=false;textSize=15f;minWidth=0;minimumWidth=0
        setPadding(dp(8),dp(4),dp(8),dp(4));setTextColor(if(primary)Color.WHITE else pine)
        background=bg(if(primary)this@Main.primary else secondary,9)
        minHeight=dp(46);minimumHeight=dp(46)
        val horizontal=parent.orientation==0
        parent.addView(this,LinearLayout.LayoutParams(if(horizontal)0 else -1,-2,if(horizontal)1f else 0f).apply{setMargins(dp(2),dp(3),dp(2),dp(3))})
        setOnClickListener{attempt(fn)}
    }
    fun field(parent:LinearLayout,title:String,value:String="",type:Int=InputType.TYPE_CLASS_TEXT):EditText{
        val id=View.generateViewId();label(parent,title,14,muted,true).labelFor=id
        return EditText(this).apply{this.id=id;inputType=type;setSingleLine(type and InputType.TYPE_TEXT_FLAG_MULTI_LINE==0);setText(value);parent.addView(this)}
    }
    fun note(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
    fun attempt(fn:()->Unit){try{fn()}catch(e:Exception){note(e.localizedMessage?:"Could not complete that action.")}}
    fun popup(title:String,body:View,positive:String="Save",fn:()->Unit){
        dialog?.dismiss()
        val wrap=ScrollView(this);wrap.addView(body)
        dialog=AlertDialog.Builder(this).setTitle(title).setView(wrap).setNegativeButton("Cancel",null).setPositiveButton(positive,null).create().also{d->
            d.show();d.getButton(-1).setOnClickListener{attempt{fn();d.dismiss()}}
        }
    }
    fun form()=col().apply{padded(this,16);isFocusableInTouchMode=true}
    fun confirm(title:String,body:String,yes:String,fn:()->Unit){
        dialog=AlertDialog.Builder(this).setTitle(title).setMessage(body).setNegativeButton("Cancel",null).setPositiveButton(yes){_,_->attempt(fn)}.show()
    }
    fun choose(title:String,options:List<String>,fn:(Int)->Unit){
        dialog=AlertDialog.Builder(this).setTitle(title).setItems(options.toTypedArray()){_,i->attempt{fn(i)}}.setNegativeButton("Cancel",null).show()
    }
    fun draw(){
        volumeControlStream=android.media.AudioManager.USE_DEFAULT_STREAM_TYPE
        tick=null;shell=col();shell.setBackgroundColor(cream);setContentView(shell)
        window.statusBarColor=primary;window.navigationBarColor=primary
        if(Build.VERSION.SDK_INT>=35)window.decorView.systemUiVisibility=if(dark)0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        if(Build.VERSION.SDK_INT>=35){
            shell.setOnApplyWindowInsetsListener{v,i->
                val b=i.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout() or WindowInsets.Type.ime())
                v.setPadding(b.left,b.top,b.right,b.bottom);i
            };shell.requestApplyInsets()
        }
        val top=col(shell);top.setBackgroundColor(primary);top.setPadding(dp(18),dp(8),dp(18),dp(8))
        val bar=row(top);bar.gravity=Gravity.CENTER_VERTICAL
        label(bar,"Time",24,Color.WHITE,true).layoutParams=LinearLayout.LayoutParams(0,-2,1f)
        val gear=ImageButton(this).apply{
            setImageResource(R.drawable.settings_gear);contentDescription="Settings";tooltipText="Settings"
            val attr=android.util.TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless,attr,true)
            setBackgroundResource(attr.resourceId);setOnClickListener{go("Settings")}
        }
        bar.addView(gear,LinearLayout.LayoutParams(dp(48),dp(48)))
        ringLabel?.let{t->action(top,"Dismiss • "+t){stopService(Intent(this,Ring::class.java));getSharedPreferences("ring",0).edit().remove("label").apply();ringLabel=null;draw()}}
        val sc=ScrollView(this);shell.addView(sc,LinearLayout.LayoutParams(-1,0,1f));sheet=col();padded(sheet,14);sc.addView(sheet)
        when(page){"Clock"->clockScreen();"Timecard"->cardScreen();"Profiles"->profilesScreen(false);"Settings"->settingsScreen();"Admin"->adminScreen()}
        val nav=row(shell);padded(nav,4);OpeningPage.tabs.forEach{s->action(nav,s,s==page){go(s)}}
    }
    fun current():Person?{val all=db.people();return all.find{it.id==prefs.getLong("person",0)}?:all.firstOrNull()}
    fun pick(p:Person){prefs.edit().putLong("person",p.id).apply();draw()}
    fun export(name:String,body:String){
        exportBytes(name,"text/csv",body.toByteArray())
    }
    fun exportBytes(name:String,mime:String,bytes:ByteArray){
        val f=File.createTempFile("export-", ".tmp",cacheDir);f.writeBytes(bytes)
        pendingFile?.let{File(cacheDir,it).delete()};pendingFile=f.name
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_TITLE,name),51)
    }
    override fun onActivityResult(request:Int,result:Int,data:Intent?){
        super.onActivityResult(request,result,data)
        if(request==56 && result==RESULT_OK){data?.data?.let{uri->attempt{prepareSetupPin(uri)}};return}
        if(request==55 && result==RESULT_OK){data?.data?.let{uri->attempt{signSetupFile(uri)}};return}
        if(request==54 && result==RESULT_OK){data?.data?.let{uri->attempt{reviewSetup(uri)}};return}
        if(request==51){val f=pendingFile?.let{File(cacheDir,it)};pendingFile=null
            try{if(result==RESULT_OK && f!=null)attempt{
                val out=contentResolver.openOutputStream(requireNotNull(data?.data),"wt")?:error("Unable to write the selected file.")
                out.use{o->f.inputStream().use{it.copyTo(o)}};note("File saved.")
            }}finally{f?.delete()};return
        }
        if(request in 52..53 && result==RESULT_OK)data?.data?.let{uri->attempt{
            val reader=contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?:error("Unable to open CSV.")
            val raw=reader.use{r->val out=StringBuilder();val buf=CharArray(8192);while(true){val n=r.read(buf);if(n<0)break;out.append(buf,0,n);require(out.length<=2000000){"File is too large."}};out.toString()}
            val isJob=request==53
            val people=if(isJob)emptyList()else Csv.parse(raw)
            val jobs=if(isJob)JobCsv.parse(raw)else emptyList()
            val apply={confirm(if(isJob)"Import job profiles?" else "Import worker profiles?",(people.size+jobs.size).toString()+" profile(s). Matching profiles will be updated.","Import"){
                if(isJob)db.importJobs(jobs)else db.importAll(people);draw();note("Profiles imported.")
            }}
            if(guard.locked){page="Admin";unlock(apply)}else apply()
        }}
    }
}
