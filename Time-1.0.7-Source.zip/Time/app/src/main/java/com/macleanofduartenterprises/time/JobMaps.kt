package com.macleanofduartenterprises.time

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

private fun Main.launchMap(uri:Uri,pkg:String?=null):Boolean=try{
    startActivity(Intent(Intent.ACTION_VIEW,uri).setPackage(pkg));true
}catch(_:ActivityNotFoundException){false}catch(_:SecurityException){false}

fun Main.openJobMap(address:String){
    val query=Uri.encode(address)
    val web=Uri.parse("https://www.openstreetmap.org/search?query="+query)
    choose("Navigate to job site",listOf("OsmAnd (online address lookup)","Google Maps","OpenStreetMap","Other map application")){index->
        when(index){
            0->{
                note("Looking up the job site on OpenStreetMap…")
                thread{
                    val result=runCatching{
                        val coordinates=address.split(',').map{it.trim().toDoubleOrNull()}
                        if(coordinates.size==2 && (coordinates[0] ?: Double.NaN) in -90.0..90.0 && (coordinates[1] ?: Double.NaN) in -180.0..180.0)coordinates.joinToString(",") else {
                            val conn=URL("https://nominatim.openstreetmap.org/search?format=json&limit=1&q="+query).openConnection() as HttpURLConnection
                            try{
                                conn.connectTimeout=10000;conn.readTimeout=12000
                                conn.setRequestProperty("User-Agent","MODE-Time/1.0.4 (https://macleanofduartenterprises.com)")
                                val match=JSONArray(conn.inputStream.bufferedReader().use{it.readText()}).optJSONObject(0)?:error("No address match. Check the job address or choose another map.")
                                val lat=match.getDouble("lat");val lon=match.getDouble("lon")
                                require(lat in -90.0..90.0 && lon in -180.0..180.0)
                                "$lat,$lon"
                            }finally{conn.disconnect()}
                        }
                    }
                    runOnUiThread{if(visible && !isFinishing && !isDestroyed)attempt{
                        val uri=Uri.parse("google.navigation:q="+result.getOrThrow()+"&mode=d")
                        if(listOf("net.osmand.plus","net.osmand").none{launchMap(uri,it)})note("OsmAnd could not open. Choose another map.")
                    }}
                }
            }
            1->if(!launchMap(Uri.parse("google.navigation:q="+query+"&mode=d"),"com.google.android.apps.maps"))
                check(launchMap(Uri.parse("https://www.google.com/maps/dir/?api=1&destination="+query))){"No map or browser is available."}
            2->check(launchMap(web)){"No browser is available."}
            else->if(!launchMap(Uri.parse("geo:0,0?q="+query)))check(launchMap(web)){"No map or browser is available."}
        }
    }
}
