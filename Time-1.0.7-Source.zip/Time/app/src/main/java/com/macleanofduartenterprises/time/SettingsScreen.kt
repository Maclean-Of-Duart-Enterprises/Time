package com.macleanofduartenterprises.time

import android.content.Intent
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import android.widget.Switch
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.*

object OpeningPage {
    val choices=linkedMapOf("clock" to "Clock","timecard" to "Timecard","profiles" to "Profiles","last" to "Last opened")
    val tabs=listOf("Clock","Timecard","Profiles")

    fun resolve(choice:String,last:String?,restored:String?=null,tool:String?=null):String{
        if(restored in tabs || restored=="Settings" || restored=="Admin")return requireNotNull(restored)
        if(tool!=null)return "Clock"
        if(choice=="last")return last?.takeIf{it in tabs}?:"Clock"
        return choices[choice]?:"Clock"
    }
}
data class Appearance(val theme:String="automatic",val face:String="digital",val hourFormat:String="system",val seconds:Boolean=true,val openingPage:String="clock"){
    init {
        require(openingPage in OpeningPage.choices){"Choose clock, timecard, profiles or last for opening_page."}
        require(theme in listOf("automatic","dark","light")){"Choose automatic, dark or light for theme."}
        require(face in listOf("digital","analog","both")){"Choose digital, analog or both for clock_face."}
        require(hourFormat in listOf("system","12","24")){"Choose system, 12 or 24 for hour_format."}
    }
    fun night(uiMode:Int)=theme=="dark" || theme=="automatic" && uiMode and Configuration.UI_MODE_NIGHT_MASK==Configuration.UI_MODE_NIGHT_YES
    fun is24(system:Boolean)=hourFormat=="24" || hourFormat=="system" && system
    fun pattern(system:Boolean):String{
        val hours24=is24(system)
        return (if(hours24)"HH:mm" else "h:mm")+(if(seconds)":ss" else "")+(if(hours24)"" else " a")
    }
}
fun Main.use24()=appearance.is24(android.text.format.DateFormat.is24HourFormat(this))
fun Main.refreshAppearance(){
    appearance=db.appearance()
    if(appearance.night(resources.configuration.uiMode)!=dark)recreate() else draw()
}

fun Main.settingsScreen(){
    heading("Settings")
    val box=card()
    fun option(title:String,choices:Map<String,String>,value:String,set:(String)->Appearance){
        action(box,title+" · "+choices.getValue(value)){
            choose(title,choices.values.toList()){i->
                db.saveAppearance(set(choices.keys.elementAt(i)));refreshAppearance()
            }
        }
    }
    option("Default opening page",OpeningPage.choices,appearance.openingPage){appearance.copy(openingPage=it)}
    option("App theme",linkedMapOf("automatic" to "Automatic (system)","light" to "Light","dark" to "Dark"),appearance.theme){appearance.copy(theme=it)}
    option("Clock display",linkedMapOf("digital" to "Digital","analog" to "Analog","both" to "Analog and digital"),appearance.face){appearance.copy(face=it)}
    option("Hour format",linkedMapOf("system" to "Device setting","12" to "12-hour","24" to "24-hour"),appearance.hourFormat){appearance.copy(hourFormat=it)}
    box.addView(Switch(this).apply{
        text="Show seconds";textSize=16f;minHeight=dp(48);isChecked=appearance.seconds
        setOnCheckedChangeListener{_,on->attempt{db.saveAppearance(appearance.copy(seconds=on));refreshAppearance()}}
    })
    val setup=card()
    action(setup,"Import employee setup JSON",true){
        guard.leave()
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),54)
    }
    action(sheet,"Admin panel"){go("Admin")}
}

class ClockDial(private val main:Main,private val zone:String?,private val seconds:Boolean):View(main){
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    private val formatter=DateTimeFormatter.ofPattern(main.appearance.pattern(main.use24()))
    init { importantForAccessibility=IMPORTANT_FOR_ACCESSIBILITY_YES }
    override fun onDraw(canvas:Canvas){
        super.onDraw(canvas)
        val now=ZonedDateTime.now(zone?.let(ZoneId::of)?:ZoneId.systemDefault())
        val radius=min(width,height)*0.44f
        if(radius<=0)return
        val x=width/2f;val y=height/2f
        paint.style=Paint.Style.STROKE;paint.color=main.muted;paint.strokeWidth=radius*.018f
        canvas.drawCircle(x,y,radius,paint)
        paint.style=Paint.Style.FILL;paint.textAlign=Paint.Align.CENTER;paint.textSize=radius*.18f
        paint.strokeCap=Paint.Cap.ROUND
        for(hour in 1..12){
            val angle=hour*Math.PI/6
            val dx=sin(angle).toFloat();val dy=-cos(angle).toFloat()
            canvas.drawText(hour.toString(),x+dx*radius*.81f,y+dy*radius*.81f-(paint.ascent()+paint.descent())/2,paint)
        }
        fun hand(units:Double,length:Float,weight:Float,color:Int){
            val angle=units*Math.PI/30
            paint.color=color;paint.strokeWidth=radius*weight
            canvas.drawLine(x,y,x+sin(angle).toFloat()*radius*length,y-cos(angle).toFloat()*radius*length,paint)
        }
        hand((now.hour%12)*5+now.minute/12.0,.50f,.06f,main.ink)
        hand(now.minute+(if(seconds)now.second/60.0 else 0.0),.70f,.04f,main.ink)
        if(seconds)hand(now.second.toDouble(),.88f,.017f,main.pine)
        canvas.drawCircle(x,y,radius*.045f,paint)
        val description=now.format(formatter)
        if(contentDescription!=description)contentDescription=description
        val step=if(seconds)1000L else 60000L
        postInvalidateDelayed(step-System.currentTimeMillis()%step)
    }
}
