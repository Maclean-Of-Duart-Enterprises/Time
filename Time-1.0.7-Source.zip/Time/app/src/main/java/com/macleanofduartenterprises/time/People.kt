package com.macleanofduartenterprises.time

import android.content.Intent
import android.text.InputType
import android.widget.*

fun Main.unlock(after:()->Unit={draw()}){
    val box=form();val pin=field(box,"Admin PIN","",InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
    popup("Unlock admin panel",box,"Unlock"){guard.unlock(pin.text.toString());after()}
}
fun Main.adminScreen(){
    heading("Admin panel")
    if(guard.locked && !guard.unlocked){
        val b=card();label(b,"Worker and job profiles are locked",20,ink,true)
        label(b,"Enter your admin PIN to edit details, import profiles or turn off controls.",15,muted)
        action(b,"Unlock admin panel",true){unlock()};return
    }
    val b=card()
    val sw=Switch(this);sw.text="Admin controls";sw.textSize=18f;sw.isChecked=guard.locked;b.addView(sw)
    label(b,if(guard.locked)"Your PIN protects profile edits. Leaving Admin locks the panel." else "Anyone using this device can edit worker and job profiles.",15,muted)
    sw.setOnCheckedChangeListener{_,on->
        draw()
        if(on){
            val form=form();val type=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            val a=field(form,"Choose a PIN (6–12 digits)","",type);val b2=field(form,"Confirm PIN","",type)
            popup("Turn on admin controls",form,"Enable"){require(a.text.toString()==b2.text.toString()){"PINs do not match."};guard.enable(a.text.toString());draw()}
        }else confirm("Turn off admin controls?","Worker and job profiles and CSV imports will be editable without a PIN.","Turn off"){
            guard.disable();draw()
        }
    }
    if(guard.locked)action(b,"Lock panel now"){guard.leave();draw()}
    trustedSenderControls(b)
    profilesScreen(true)
}
fun Main.profilesScreen(admin:Boolean){
    val tabs=row(sheet)
    action(tabs,"Workers",!jobsTab){jobsTab=false;draw()}
    action(tabs,"Jobs",jobsTab){jobsTab=true;draw()}
    if(jobsTab)jobsScreen(admin) else peopleScreen(admin)
}
fun Main.peopleScreen(admin:Boolean){
    if(!admin)heading("Worker profiles") else label(sheet,"Worker profiles",20,ink,true)
    val editable=!guard.locked || (admin && guard.unlocked)
    if(editable){
        val r=row(sheet);action(r,"Add worker",true){editPerson(null)};action(r,"Import CSV"){
            guard.check()
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),52)
        }
    }else label(sheet,"Profile details are read-only while admin controls are on.",15,muted)
    val profiles=db.people()
    if(profiles.isEmpty()){
        label(sheet,"No workers yet. Add a worker or import a profile CSV.",16)
    }else{
        if(editable)action(sheet,"Export profile CSV"){guard.check();export("Time-worker-profiles.csv",Csv.profiles(profiles))}
        for(p in profiles){
            val b=card();label(b,p.name,20,ink,true)
            if(p.employee.isNotBlank())label(b,"MODE employee ID  "+p.employee,15)
            if(p.business.isNotBlank())label(b,"MODE business ID  "+p.business,15)
            for((k,v) in p.fields)label(b,k+"  ·  "+v,15)
            for(file in db.employeeFiles(p.id))action(b,"Save file · "+file){
                val (mime,data)=db.employeeFile(p.id,file);exportBytes(file,mime,data)
            }
            if(editable){
                val actions=row(b)
                action(actions,"Edit profile"){editPerson(p)}
                action(actions,"Delete employee"){
                    val history=db.workerHistory(p.id)
                    val warning=buildString{
                        append("Permanently delete "+p.name+"?")
                        if(history.shifts>0)append("\n\nThis also deletes "+history.shifts+" timecard shift(s) and their breaks.")
                        if(history.running>0)append(" This includes a running shift.")
                        if(history.files>0)append("\n\nEmployee files to delete: "+history.files)
                    }
                    confirm("Delete employee?",warning,"Delete"){
                        db.deleteWorker(p,history)
                        val edit=prefs.edit().remove("job-for-"+p.id)
                        if(prefs.getLong("person",0)==p.id)edit.remove("person")
                        edit.apply();draw()
                    }
                }
            }
        }
    }
}
fun Main.editPerson(old:Person?){
    guard.check();val b=form()
    val name=field(b,"Worker name",old?.name.orEmpty())
    val emp=field(b,"MODE employee ID (optional)",old?.employee.orEmpty(),InputType.TYPE_CLASS_NUMBER)
    val biz=field(b,"MODE business profile ID (optional)",old?.business.orEmpty(),InputType.TYPE_CLASS_NUMBER)
    val fields=customFields(b,old?.fields.orEmpty())
    popup(if(old==null)"Add worker" else "Edit worker",b){
        val id=db.edit(Person(old?.id?:0,name.text.toString().trim(),emp.text.toString().trim(),biz.text.toString().trim(),fields()))
        if(old==null)prefs.edit().putLong("person",id).apply()
        draw()
    }
}

fun Main.customFields(b:LinearLayout,initial:Map<String,String>):()->Map<String,String>{
    val rows=mutableListOf<Pair<EditText,EditText>>()
    val items=col(b)
    fun custom(k:String,v:String){
        val group=card(items);val key=field(group,"Custom field label",k);val value=field(group,"Value",v,InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)
        val pair=key to value;rows+=pair
        action(group,"Remove field"){rows.remove(pair);items.removeView(group)}
    }
    initial.forEach(::custom)
    action(b,"Add custom field"){custom("","")}
    return {
        val pairs=rows.map{it.first.text.toString().trim() to it.second.text.toString()}
        require(pairs.map{Csv.head(it.first)}.distinct().size==pairs.size){"Custom field labels must be unique."}
        pairs.toMap()
    }
}
