package com.macleanofduartenterprises.time

import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONObject
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.util.Base64

private const val ALIAS="time.employee-setup.sender.v1"
private fun senderStore():KeyStore{
    val store=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
    if(!store.containsAlias(ALIAS)){
        val spec=KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_SIGN)
            .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1")).setDigests(KeyProperties.DIGEST_SHA256).build()
        KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC,"AndroidKeyStore").apply{initialize(spec);generateKeyPair()}
    }
    return store
}
fun Main.showSenderKey(){
    val pem="-----BEGIN PUBLIC KEY-----\n"+Base64.getEncoder().encodeToString(senderStore().getCertificate(ALIAS).publicKey.encoded)+"\n-----END PUBLIC KEY-----"
    val b=form()
    label(b,"On each employee phone, open Settings → Admin panel → Trust setup sender and paste this public key.",16)
    label(b,pem,14,muted).setTextIsSelectable(true)
    popup("This device’s sender key",b,"Copy public key"){
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Time setup public key",pem));note("Public key copied.")
    }
}
fun Main.signSetupFile(uri:Uri)=readSetupFile(uri){bytes,setup->
    require(setup.signature==null && setup.password==null){"Choose an unsigned setup JSON with the admin password omitted."}
    val box=form()
    label(box,setup.summary(),16)
    val pin=if(guard.locked)field(box,"Admin PIN to sign this setup","",
        android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD) else null
    popup("Sign employee setup?",box,"Sign and save"){
        guard.leave()
        if(guard.locked)guard.verifyPin(pin?.text?.toString().orEmpty())
        val key=senderStore().getKey(ALIAS,null) as PrivateKey
        val signature=Signature.getInstance("SHA256withECDSA").run{initSign(key);update(bytes);sign()}
        val encoder=Base64.getEncoder()
        val body=JSONObject().put("format","time.signed.v1").put("payload",encoder.encodeToString(bytes))
            .put("signature",encoder.encodeToString(signature)).toString().toByteArray()
        require(body.size<=SetupCodec.MAX_BYTES){"The signed file exceeds 16 MiB. Split the employee attachments into smaller files."}
        exportBytes("Time-employee-setup-signed.json","application/json",body)
    }
}
