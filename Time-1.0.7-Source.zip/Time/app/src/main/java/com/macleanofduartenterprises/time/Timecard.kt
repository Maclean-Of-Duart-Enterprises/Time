package com.macleanofduartenterprises.time

import android.app.DatePickerDialog
import android.text.InputType
import java.time.*
import java.time.format.DateTimeFormatter

fun Main.cardScreen(){
    heading("Timecard")
    val people=db.people();val p=current()
    if(p==null){
        val b=card();label(b,"Add a worker to start a timecard.",18)
        action(b,if(guard.locked)"Open settings" else "Add worker",true){if(guard.locked)go("Settings")else editPerson(null)}
        return
    }
    val b=card();label(b,p.name,22,ink,true)
    if(people.size>1)action(b,"Choose worker"){choose("Worker",people.map{it.name+(if(it.employee.isNotBlank())" · "+it.employee else "")}){pick(people[it])}}
    val live=db.live(p.id)
    if(live==null){
        label(b,"Clocked out",16,muted)
        val jobs=db.jobs().filterNot{it.archived}
        val key="job-for-"+p.id
        val job=jobs.firstOrNull{it.id==prefs.getLong(key,0)}
        if(jobs.isNotEmpty())action(b,"Job · "+(job?.caption?:"Unassigned")){
            choose("Select job",listOf("Unassigned")+jobs.map{it.caption}){ix->prefs.edit().putLong(key,jobs.getOrNull(ix-1)?.id?:0).apply();draw()}
        }
        action(b,"Clock in",true){
            val form=form();val text=field(form,"Job or shift notes (optional)","",InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)
            if(job!=null)label(form,job.caption,18,ink,true)
            val factor=if(guard.locked){label(form,"Pay multiplier  ×"+(job?.factor?:"1"));null}else field(form,"Pay multiplier",job?.factor?:"1",InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
            popup("Clock in · "+p.name,form,"Clock in"){db.start(p.id,text.text.toString(),factor?.text?.toString()?:"1",job?.id?:0);draw()}
        }
    }else{
        label(b,if(live.paused!=null)"On unpaid break" else "Clocked in",16,muted,true)
        val time=label(b,"",34,pine,true)
        tick={val elapsed=(live.paused?:live.rec.timeEnded)-live.rec.timeStarted-live.unpaidMs;time.text=Cards.duration(elapsed.coerceAtLeast(0)/1000)}
        tick?.invoke()
        if(live.rec.comment.isNotBlank())label(b,live.rec.comment)
        val r=row(b);action(r,if(live.paused!=null)"End break" else "Start break"){db.punch(p.id,false);draw()}
        action(r,"Clock out",true){db.punch(p.id,true);draw()}
    }
    action(b,"Add manual shift"){openShiftEditor(p)}
    label(sheet,"Pay period",21,ink,true)
    val range=row(sheet)
    fun chooseDate(start:Boolean){val date=if(start)from else to
        DatePickerDialog(this,{_,y,m,d->
            val chosen=LocalDate.of(y,m+1,d)
            if(start){from=chosen;if(to<from)to=from}else{to=chosen;if(from>to)from=to}
            draw()
        },date.year,date.monthValue-1,date.dayOfMonth).show()
    }
    action(range,"From\n"+from){chooseDate(true)};action(range,"Through\n"+to){chooseDate(false)}
    val shifts=db.shifts(p.id)
    val selected=shifts.filter{Cards.intersects(it,from,to)}
    val sec=selected.sumOf{s->Cards.segments(s).filter{it.date>=from && it.date<=to}.sumOf{it.paid}}
    label(sheet,Cards.duration(sec)+" paid  ·  "+selected.size+" completed shift"+if(selected.size==1)"" else "s",17,ink,true)
    action(sheet,"Export timecard CSV",true){
        val csv=Cards.export(p,selected,from,to)
        val safe=p.name.replace(Regex("[^\\p{L}\\p{N}._-]+"),"-").take(60)
        export("Time-"+safe+"-"+from+"-to-"+to+".csv",csv)
    }
    if(selected.isNotEmpty())action(sheet,"Delete timecard"){
        val startDate=from
        val endDate=to
        val details=p.name+" · "+startDate+" through "+endDate+"\n"+Cards.duration(sec)+" paid across "+selected.size+" completed shift(s). This permanently deletes the time shown for this period."
        confirmTimeDeletion("Delete timecard?",details){db.deleteTimecard(p.id,startDate,endDate,selected)}
    }
    if(selected.isEmpty())label(sheet,"Completed shifts appear here for the selected dates.",15,muted)
    val pageSize=20
    var ix=prefs.getInt("historyPage",0).coerceIn(0,(selected.size-1).coerceAtLeast(0)/pageSize)
    selected.drop(ix*pageSize).take(pageSize).forEach{s->
        val box=card();val f=DateTimeFormatter.ofPattern("MMM d, HH:mm:ss");val rec=s.record
        fun stamp(t:Long)=f.format(Instant.ofEpochMilli(t).atZone(s.zone))
        label(box,stamp(rec.timeStarted)+" – "+stamp(rec.timeEnded),17,ink,true)
        val unpaid=s.breaks.sumOf{it.duration}/1000
        label(box,Cards.duration(rec.duration/1000-unpaid)+" paid  ·  "+Cards.duration(unpaid)+" break"+if(s.factor!="1")"  ·  ×"+s.factor else "",15,muted)
        if(rec.comment.isNotBlank())label(box,rec.comment)
        val shiftActions=row(box)
        action(shiftActions,"Edit shift"){openShiftEditor(p,s)}
        action(shiftActions,"Delete shift"){
            val details=p.name+" · "+stamp(rec.timeStarted)+" – "+stamp(rec.timeEnded)+"\nThis permanently deletes this entire shift and its recorded breaks."
            confirmTimeDeletion("Delete shift?",details){db.deleteShift(p.id,s)}
        }
    }
    if(selected.size>pageSize){val r=row(sheet);if(ix>0)action(r,"Previous"){prefs.edit().putInt("historyPage",ix-1).apply();draw()}
        if((ix+1)*pageSize<selected.size)action(r,"Next"){prefs.edit().putInt("historyPage",ix+1).apply();draw()}}
}

private fun Main.confirmTimeDeletion(title:String,details:String,remove:()->Unit){
    val show={
        confirm(title,details,"Delete"){
            remove()
            draw()
            note("Deleted.")
        }
        dialog?.setOnDismissListener{guard.leave()}
        Unit
    }
    if(guard.locked && !guard.unlocked)unlock(show) else show()
}
