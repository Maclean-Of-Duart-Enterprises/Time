package com.macleanofduartenterprises.time

import android.app.*
import android.content.*
import android.media.*
import android.os.*
import android.provider.Settings
import android.net.Uri
import org.json.JSONObject
import java.time.*

data class Bell(val id:Int,val hour:Int,val minute:Int,val label:String,val days:Int,val due:Long,val alert:AlertOptions=AlertOptions(),val enabled:Boolean=true)
data class AlarmEvent(val label:String,val alert:AlertOptions)
class Bells(val context:Context){
    private val p=context.getSharedPreferences("bells",0)
    private val am=context.getSystemService(AlarmManager::class.java)
    val exact get()=Build.VERSION.SDK_INT<31 || am.canScheduleExactAlarms()
    fun alarms()=p.all.keys.filter{it.startsWith("a:")}.map{key->
        val j=JSONObject(p.getString(key,"{}")!!)
        Bell(key.substring(2).toInt(),j.getInt("h"),j.getInt("m"),j.getString("label"),j.optInt("days",if(j.optBoolean("daily"))AlarmDays.DAILY else 0),j.getLong("due"),AlertOptions.read(j.optJSONObject("alert")),j.optBoolean("enabled",true))
    }.sortedWith(compareBy({it.hour},{it.minute},{it.id}))
    private fun fireIntent(id:Int,due:Long)=PendingIntent.getBroadcast(context,id,Intent(context,Wake::class.java).setAction("ring").putExtra("id",id).putExtra("due",due),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    private fun schedule(b:Bell){
        require(exact){"Allow alarms and reminders in Android settings first."}
        val show=PendingIntent.getActivity(context,b.id,Intent(context,Main::class.java).putExtra("tool","Alarms"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(b.due,show),fireIntent(b.id,b.due))
        persist(b)
    }
    private fun persist(b:Bell){
        val j=JSONObject().put("enabled",b.enabled).put("h",b.hour).put("m",b.minute).put("label",b.label).put("days",b.days).put("due",b.due).put("alert",b.alert.json())
        val editor=p.edit().putString("a:"+b.id,j.toString())
        if(b.id>=p.getInt("seq",1))editor.putInt("seq",b.id+1)
        check(editor.commit()){"Could not save alarm."}
    }
    fun save(id:Int?,h:Int,m:Int,label:String,days:Int,alert:AlertOptions=AlertOptions()){
        val previous=id?.let{alarm(it)}
        val active=previous?.enabled?:true
        val b=Bell(id?:p.getInt("seq",1),h,m,label.trim().ifBlank{"Alarm"},days,
            if(active)AlarmDays.next(h,m,days) else 0L,alert,active)
        if(active)schedule(b) else persist(b)
    }
    private fun alarm(id:Int)=alarms().firstOrNull{it.id==id}?:error("This alarm was deleted.")
    fun setEnabled(id:Int,enabled:Boolean){
        val b=alarm(id)
        if(b.enabled==enabled)return
        if(enabled)schedule(b.copy(enabled=true,due=AlarmDays.next(b.hour,b.minute,b.days)))
        else {
            disable(b)
            stopRinging(id)
        }
    }
    private fun disable(b:Bell){
        persist(b.copy(enabled=false,due=0L))
        am.cancel(fireIntent(b.id,0))
    }
    private fun stopRinging(id:Int){
        if(context.getSharedPreferences("ring",0).getInt("id",-1)==id)
            context.stopService(Intent(context,Ring::class.java))
    }
    fun remove(id:Int){
        check(p.edit().remove("a:"+id).commit()){"Could not delete alarm."}
        am.cancel(fireIntent(id,0));stopRinging(id)
    }
    val timerRunning get()=p.contains("elapsed")
    val timerRemaining:Long get()=if(timerRunning)(p.getLong("elapsed",0)-SystemClock.elapsedRealtime()).coerceAtLeast(0) else p.getLong("remaining",0)
    fun time(ms:Long){
        require(exact){"Allow alarms and reminders in Android settings first."}
        require(ms>0 && ms<=604800000){"Choose a duration up to seven days."}
        val at=SystemClock.elapsedRealtime()+ms
        am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,at,fireIntent(0,at))
        p.edit().putLong("elapsed",at).putLong("wall",System.currentTimeMillis()+ms).remove("remaining").commit()
    }
    fun pause(){val left=timerRemaining;reset();p.edit().putLong("remaining",left).commit()}
    fun reset(){p.edit().remove("elapsed").remove("remaining").remove("wall").commit();am.cancel(fireIntent(0,0))}
    fun consume(id:Int,due:Long):AlarmEvent? {
        if(id==0){if(!timerRunning || p.getLong("elapsed",-1)!=due)return null;reset();return AlarmEvent("Timer finished",AlertOptions())}
        val b=alarms().find{it.enabled && it.id==id && it.due==due}?:return null
        if(b.days==0)disable(b) else {
            val after=Instant.ofEpochMilli(maxOf(System.currentTimeMillis(),due)).atZone(ZoneId.systemDefault())
            schedule(b.copy(due=AlarmDays.next(b.hour,b.minute,b.days,after)))
        }
        return AlarmEvent(b.label,b.alert)
    }
    fun restore(action:String){
        if(!exact)return
        val now=System.currentTimeMillis()
        alarms().filter{it.enabled}.forEach{b->
            val zoneChanged=action==Intent.ACTION_TIMEZONE_CHANGED || action==Intent.ACTION_TIME_CHANGED
            when{
                zoneChanged->schedule(b.copy(due=AlarmDays.next(b.hour,b.minute,b.days)))
                b.due>now->schedule(b)
                now-b.due<600000 && (b.days==0 || AlarmDays.includes(b.days,LocalDate.now().dayOfWeek))->schedule(b.copy(due=now+2000))
                b.days!=0->schedule(b.copy(due=AlarmDays.next(b.hour,b.minute,b.days)))
                else->disable(b)
            }
        }
        if(timerRunning){
            if(action==Intent.ACTION_TIME_CHANGED || action==Intent.ACTION_TIMEZONE_CHANGED){
                p.edit().putLong("wall",now+timerRemaining).commit()
            }else{
                val ms=if(action==Intent.ACTION_BOOT_COMPLETED)p.getLong("wall",now)-now else timerRemaining
                time(ms.coerceIn(1000L,604800000L))
            }
        }
    }
}
class Wake:BroadcastReceiver(){
    override fun onReceive(c:Context,i:Intent){
        val bells=Bells(c)
        if(i.action=="ring"){
            val event=bells.consume(i.getIntExtra("id",-1),i.getLongExtra("due",-1))?:return
            c.startForegroundService(Intent(c,Ring::class.java).putExtra("id",i.getIntExtra("id",-1)).putExtra("label",event.label).putExtra("alert",event.alert.json().toString()))
        }else if(i.action!=null)bells.restore(i.action!!)
    }
}
class Ring:Service(){
    private val output by lazy{AlertOutput(this)}
    private val handler=Handler(Looper.getMainLooper())
    private lateinit var prefs:SharedPreferences
    override fun onBind(i:Intent?)=null
    override fun onCreate(){super.onCreate();prefs=getSharedPreferences("ring",0)}
    override fun onStartCommand(i:Intent?,flags:Int,startId:Int):Int{
        val label=i?.getStringExtra("label")?:"Alarm"
        AlarmMedia.channel(this)
        val open=PendingIntent.getActivity(this,0,Intent(this,Main::class.java).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("tool","Clock"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop=PendingIntent.getService(this,0,Intent(this,Ring::class.java).setAction("stop"),PendingIntent.FLAG_IMMUTABLE)
        if(i?.action=="stop"){stopSelf();return START_NOT_STICKY}
        val n=Notification.Builder(this,"clock-ring").setSmallIcon(R.drawable.time_icon).setContentTitle(label).setContentText("Tap Dismiss to silence.").setContentIntent(open).setOngoing(true).setCategory(Notification.CATEGORY_ALARM).addAction(Notification.Action.Builder(null,"Dismiss",stop).build()).build()
        startForeground(703,n)
        prefs.edit().putInt("id",i?.getIntExtra("id",-1)?:-1).putString("label",label).commit()
        val alert=AlertOptions.read(i?.getStringExtra("alert")?.let{JSONObject(it)})
        output.start(alert)
        handler.removeCallbacksAndMessages(null);handler.postDelayed({stopSelf()},300000)
        return START_NOT_STICKY
    }
    override fun onDestroy(){
        output.stop();handler.removeCallbacksAndMessages(null)
        prefs.edit().remove("label").remove("id").commit();stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy()
    }
}
