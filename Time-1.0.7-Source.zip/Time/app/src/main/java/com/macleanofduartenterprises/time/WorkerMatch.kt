package com.macleanofduartenterprises.time

import java.text.Normalizer
import java.util.Locale

private val nameSpaces=Regex("[\\p{Z}\\s]+")
fun workerName(name:String)=nameSpaces.replace(Normalizer.normalize(name,Normalizer.Form.NFKC)," ").trim().lowercase(Locale.ROOT)

/** Resolve MODE identities first and adopt older manual profiles with the same name. */
fun setupMatches(p:Person,existing:List<Person>):List<Person>{
    val key=workerName(p.name)
    val scope=existing.filter{p.business.isEmpty() || it.business.isEmpty() || it.business==p.business}
    val named=scope.filter{workerName(it.name)==key}
    val exact=scope.filter{p.employee.isNotEmpty() && it.employee==p.employee &&
        (it.business==p.business || it in named)}
    val identified=if(exact.isNotEmpty())exact+named.filter{it.employee.isEmpty()} else named
    val matches=identified.distinctBy{it.id}.sortedBy{it.id}
    require(matches.map{it.business}.filter{it.isNotEmpty()}.distinct().size<=1 &&
        matches.map{it.employee}.filter{it.isNotEmpty()}.distinct().size<=1){
        "Several employees named "+p.name+" have different MODE identities. Specify the matching business and employee IDs."
    }
    return matches
}
