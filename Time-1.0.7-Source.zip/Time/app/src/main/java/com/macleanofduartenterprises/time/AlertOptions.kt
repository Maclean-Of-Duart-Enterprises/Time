package com.macleanofduartenterprises.time

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.*
import android.net.Uri
import android.os.*
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

enum class AlertMode(val title:String) {
    BOTH("Sound and vibration"), SOUND("Sound only"), VIBRATE("Vibration only")
}

data class AlertOptions(
    val mode:AlertMode=AlertMode.BOTH,
    val tone:String="",
    val toneName:String="Time chime",
    val pattern:String="pulse",
    val patternName:String="Steady pulse"
){
    fun json()=JSONObject().put("mode",mode.name).put("tone",tone).put("toneName",toneName)
        .put("pattern",pattern).put("patternName",patternName)
    companion object {
        fun read(j:JSONObject?):AlertOptions {
            if(j==null)return AlertOptions()
            return AlertOptions(AlertMode.values().find{it.name==j.optString("mode")}?:AlertMode.BOTH,
                j.optString("tone",""),j.optString("toneName","Time chime"),j.optString("pattern","pulse"),j.optString("patternName","Steady pulse"))
        }
    }
}

object AlarmMedia {
    const val CHANNEL="clock-ring"
    val attributes:AudioAttributes get()=AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
    fun channel(context:Context):NotificationChannel {
        val nm=context.getSystemService(NotificationManager::class.java)
        val existing=nm.getNotificationChannel(CHANNEL)
        if(existing!=null)return existing
        val channel=NotificationChannel(CHANNEL,"Clock alarms and timer",NotificationManager.IMPORTANCE_HIGH)
        // The ringing service plays the selected alert once, independently of notification sound.
        channel.setSound(null,null);channel.enableVibration(false)
        nm.createNotificationChannel(channel)
        return nm.getNotificationChannel(CHANNEL)
    }
    fun displayName(context:Context,uri:Uri):String =
        context.contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{
            if(it.moveToFirst())it.getString(0)else null
        } ?: "Imported file"

    private fun directory(c:Context)=File(c.filesDir,"alarm-tones").also{it.mkdirs()}
    fun imported(c:Context):Map<String,String> = c.getSharedPreferences("tone-names",0).all
        .mapNotNull{(k,v)->if(v is String && File(directory(c),k).isFile)k to v else null}.toMap()

    fun importAudio(c:Context,uri:Uri):Pair<String,String> {
        val name=displayName(c,uri)
        val dir=directory(c)
        val temp=File.createTempFile("select-", ".tmp",dir)
        try{
            val digest=MessageDigest.getInstance("SHA-256")
            (c.contentResolver.openInputStream(uri)?:error("Cannot read this file.")).use{input->
                java.security.DigestInputStream(input,digest).use{source->temp.outputStream().use{source.copyTo(it)}}
            }
            val probe=MediaPlayer()
            try{probe.setDataSource(temp.absolutePath);probe.prepare();require(probe.trackInfo.any{it.trackType==MediaPlayer.TrackInfo.MEDIA_TRACK_TYPE_AUDIO}){"Choose a file containing playable audio."}}
            finally{probe.release()}
            val key=digest.digest().joinToString(""){"%02x".format(it)}
            val dest=File(dir,key)
            if(!dest.isFile)check(temp.renameTo(dest) || dest.isFile){"Could not save this sound."}
            c.getSharedPreferences("tone-names",0).edit().putString(key,name).apply()
            return "import:"+key to name
        }finally{temp.delete()}
    }
    fun importPattern(c:Context,uri:Uri):Pair<String,String>{
        val bytes=(c.contentResolver.openInputStream(uri)?:error("Cannot open this pattern.")).use{input->
            val buffer=java.io.ByteArrayOutputStream();val block=ByteArray(1024)
            while(true){val n=input.read(block);if(n<0)break;buffer.write(block,0,n);require(buffer.size()<=8192){"Pattern exceeds 8 KB."}}
            buffer.toByteArray()
        }
        val s=bytes.toString(Charsets.UTF_8).removePrefix("\uFEFF").trim().replace(Regex("[,;\\s]+"),",")
        val values=waveform(s)
        return values.joinToString(",") to displayName(c,uri)
    }
    fun waveform(s:String):LongArray {
        val raw=when(s){"pulse"->"0,500,900";"double"->"0,180,140,180,1100";"long"->"0,900,1100";else->s}
        val parts=raw.split(',')
        require(parts.size in 2..128){"Use 2–128 alternating pause and vibration durations in milliseconds."}
        val times=parts.map{it.toLongOrNull()?.takeIf{n->n in 0..60000}?:error("Each duration must be 0–60000 milliseconds.")}.toLongArray()
        require(times.indices.any{it%2==1 && times[it]>0} && times.sum() in 1..120000){"Include a vibration and keep one cycle within two minutes."}
        return times
    }
    fun setSource(player:MediaPlayer,c:Context,tone:String){
        when{
            tone.isEmpty()->c.resources.openRawResourceFd(R.raw.time_chime).use{player.setDataSource(it.fileDescriptor,it.startOffset,it.length)}
            tone.startsWith("import:")->{
                val key=tone.removePrefix("import:");require(key.matches(Regex("[0-9a-f]{64}")))
                player.setDataSource(File(directory(c),key).absolutePath)
            }
            else->{val uri=Uri.parse(tone);require(uri.scheme=="content");player.setDataSource(c,uri)}
        }
    }
}

class AlertOutput(private val context:Context){
    private val handler=Handler(Looper.getMainLooper())
    private val vibrator=context.getSystemService(Vibrator::class.java)
    private var player:MediaPlayer?=null
    private var vibrating=false
    val playing get()=runCatching{player?.isPlaying==true}.getOrDefault(false)
    val hasVibration get()=vibrating
    fun stop(){
        handler.removeCallbacksAndMessages(null)
        player?.release();player=null
        if(vibrating){vibrator.cancel();vibrating=false}
    }
    fun start(options:AlertOptions,preview:Boolean=false){
        stop()
        if(options.mode!=AlertMode.VIBRATE)play(options.tone)
        if(options.mode!=AlertMode.SOUND && vibrator.hasVibrator()){
            vibrating=true
            val predefined=when(options.pattern){"click"->VibrationEffect.EFFECT_CLICK;"heavy"->VibrationEffect.EFFECT_HEAVY_CLICK;else->-1}
            if(Build.VERSION.SDK_INT>=29 && predefined>=0){
                val effect=VibrationEffect.createPredefined(predefined)
                val repeat=object:Runnable{override fun run(){vibrator.vibrate(effect,AlarmMedia.attributes);handler.postDelayed(this,1100)}}
                repeat.run()
            }else{
                val timings=runCatching{AlarmMedia.waveform(options.pattern)}.getOrElse{AlarmMedia.waveform("pulse")}
                vibrator.vibrate(VibrationEffect.createWaveform(timings,0),AlarmMedia.attributes)
            }
        }
        if(preview)handler.postDelayed({stop()},3500)
    }
    private fun play(tone:String){
        val candidate=MediaPlayer()
        try{
            candidate.setAudioAttributes(AlarmMedia.attributes)
            AlarmMedia.setSource(candidate,context,tone)
            candidate.isLooping=true;candidate.setWakeMode(context,PowerManager.PARTIAL_WAKE_LOCK)
            candidate.setOnErrorListener{mp,_,_->
                if(player===mp){player=null;mp.release();if(tone.isNotEmpty())play("")};true
            }
            candidate.prepare();player=candidate;candidate.start()
        }catch(e:Exception){
            player=null;candidate.release()
            if(tone.isNotEmpty())play("") else android.util.Log.e("Time","Unable to play built-in alarm",e)
        }
    }
}
