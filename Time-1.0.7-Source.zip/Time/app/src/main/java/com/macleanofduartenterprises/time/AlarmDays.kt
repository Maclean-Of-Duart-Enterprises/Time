package com.macleanofduartenterprises.time

import java.time.DayOfWeek
import java.time.LocalTime
import java.time.ZonedDateTime
import java.time.format.TextStyle
import java.util.Locale

object AlarmDays {
    const val DAILY = 127
    fun bit(day: DayOfWeek) = 1 shl (day.value - 1)
    fun includes(mask: Int, day: DayOfWeek) = mask and bit(day) != 0

    fun label(mask: Int): String = when (mask) {
        0 -> "Once"
        DAILY -> "Every day"
        else -> DayOfWeek.values().filter { includes(mask, it) }.joinToString(", ") {
            it.getDisplayName(TextStyle.SHORT, Locale.getDefault())
        }
    }

    fun next(hour: Int, minute: Int, mask: Int, after: ZonedDateTime = ZonedDateTime.now()): Long {
        require(mask in 0..DAILY)
        val time = LocalTime.of(hour, minute)
        for (offset in 0L..7L) {
            val date = after.toLocalDate().plusDays(offset)
            if (mask != 0 && !includes(mask, date.dayOfWeek)) continue
            val candidate = date.atTime(time).atZone(after.zone)
            if (candidate.isAfter(after)) return candidate.toInstant().toEpochMilli()
        }
        error("No upcoming alarm day.")
    }
}
