package com.macleanofduartenterprises.time

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.net.Uri
import android.text.*
import android.widget.*
import android.graphics.Typeface
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale

private fun Main.clockFace(parent:LinearLayout,zone:String?,large:Boolean){
    val settings=appearance
    if(settings.face!="digital"){
        parent.addView(ClockDial(this,zone,settings.seconds),LinearLayout.LayoutParams(-1,dp(if(large)236 else 160)))
    }
    if(settings.face!="analog"){
        val c=TextClock(this)
        c.format12Hour=settings.pattern(false);c.format24Hour=settings.pattern(true);if(zone!=null)c.timeZone=zone
        c.textSize=if(large)43f else 28f;c.setTextColor(pine)
        c.typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL);parent.addView(c)
    }
    val date=TextClock(this);date.format12Hour="EEEE, MMMM d";date.format24Hour=date.format12Hour;if(zone!=null)date.timeZone=zone
    date.setTextColor(muted);date.textSize=16f;parent.addView(date)
}
fun Main.clockScreen(){
    val r=row(sheet);action(r,"Local clock",tool=="Clock"){tool="Clock";draw()};action(r,"World clock",tool=="World"){tool="World";draw()}
    val r2=row(sheet);action(r2,"Alarms",tool=="Alarms"){tool="Alarms";draw()};action(r2,"Timer",tool=="Timer"){tool="Timer";draw()}
    when(tool){
        "World"->{
            heading("World clock")
            val ids=prefs.getStringSet("zones",setOf("UTC")).orEmpty().sorted()
            for(id in ids){
                val b=card();label(b,id.replace('_',' '),19,ink,true);clockFace(b,id,false)
                action(b,"Remove"){prefs.edit().putStringSet("zones",ids.toSet()-id).apply();draw()}
            }
            action(sheet,"Add time zone",true){
                val box=form();val search=field(box,"Search city or region")
                val list=ListView(this);box.addView(list,LinearLayout.LayoutParams(-1,dp(290)))
                val zones=ZoneId.getAvailableZoneIds().filter{it !in ids}.sorted()
                var results=zones
                fun fill(s:String){results=zones.filter{it.replace('_',' ').contains(s,true)};list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,results.map{it.replace('_',' ')})}
                fill("");search.addTextChangedListener(object:TextWatcher{
                    override fun beforeTextChanged(s:CharSequence?,a:Int,c:Int,f:Int){}
                    override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){fill(s.toString())}
                    override fun afterTextChanged(s:Editable?){}
                })
                dialog=AlertDialog.Builder(this).setTitle("Add time zone").setView(box).setNegativeButton("Cancel",null).show()
                list.setOnItemClickListener{_,_,i,_->prefs.edit().putStringSet("zones",ids.toSet()+results[i]).apply();dialog?.dismiss();draw()}
            }
        }
        "Alarms"->{
            volumeControlStream=android.media.AudioManager.STREAM_ALARM
            heading("Alarms");alarmPermissions()
            val entries=bells.alarms()
            if(entries.isEmpty())label(sheet,"No alarms set.",16,muted)
            entries.forEach{a->
                val b=card()
                val header=row(b)
                header.gravity=android.view.Gravity.CENTER_VERTICAL
                val time=LocalTime.of(a.hour,a.minute).format(DateTimeFormatter.ofPattern(if(use24())"HH:mm" else "h:mm a"))
                val title=label(header,time+"  ·  "+a.label,22,if(a.enabled)ink else muted,true)
                title.layoutParams=LinearLayout.LayoutParams(0,-2,1f)
                val toggle=Switch(this).apply{
                    contentDescription="Enable alarm "+a.label+" at "+time
                    minHeight=dp(48);minimumWidth=dp(48);isChecked=a.enabled
                    setOnCheckedChangeListener{_,on->
                        attempt{bells.setEnabled(a.id,on)}
                        draw()
                    }
                }
                header.addView(toggle)
                val status=if(a.enabled)Instant.ofEpochMilli(a.due).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("EEE, MMM d")) else "Off"
                label(b,AlarmDays.label(a.days)+"  ·  "+status,15,muted)
                label(b,a.alert.mode.title,14,muted)
                b.setOnClickListener{attempt{editAlarm(a)}}
                val actions=row(b)
                action(actions,"Edit alarm"){editAlarm(a)}
                action(actions,"Delete alarm"){bells.remove(a.id);draw()}
            }
            action(sheet,"Add alarm",true){editAlarm(null)}

        }
        "Timer"->{
            heading("Timer");alarmPermissions();val b=card()
            val status=label(b,"",36,pine,true)
            var active=bells.timerRunning
            tick={status.text=Cards.duration((bells.timerRemaining+999)/1000);if(active!=bells.timerRunning){active=bells.timerRunning;draw()}}
            tick?.invoke()
            if(bells.timerRunning){action(b,"Pause"){bells.pause();draw()}}
            else if(bells.timerRemaining>0){action(b,"Resume",true){bells.time(bells.timerRemaining);draw()}}
            else{
                val h=field(b,"Hours","0",InputType.TYPE_CLASS_NUMBER);val m=field(b,"Minutes","5",InputType.TYPE_CLASS_NUMBER);val s=field(b,"Seconds","0",InputType.TYPE_CLASS_NUMBER)
                action(b,"Start timer",true){
                    fun num(e:EditText,max:Int):Int{val n=e.text.toString().ifBlank{"0"}.toIntOrNull();require(n!=null && n in 0..max){"Enter a number from 0 to "+max+"."};return n}
                    bells.time((num(h,168)*3600L+num(m,59)*60+num(s,59))*1000);draw()
                }
            }
            if(bells.timerRemaining>0 || bells.timerRunning)action(b,"Reset timer"){bells.reset();draw()}
        }
        else->{heading("Local clock");if(!notificationsReady())action(sheet,"Enable alarm notifications"){enableNotifications(true)};val b=card();label(b,ZoneId.systemDefault().id.replace('_',' '),18,muted,true);clockFace(b,null,true)}
    }
}
private fun Main.alarmPermissions(){
    if(!bells.exact && Build.VERSION.SDK_INT>=31)action(sheet,"Allow alarms and reminders"){
        startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+packageName)))
    }
    if(!notificationsReady())action(sheet,"Enable alarm notifications"){enableNotifications(true)}

}

fun Main.notificationsReady():Boolean{
    val manager=getSystemService(NotificationManager::class.java)
    return manager.areNotificationsEnabled() && AlarmMedia.channel(this).importance!=NotificationManager.IMPORTANCE_NONE
}
fun Main.enableNotifications(interactive:Boolean){
    val permission=Manifest.permission.POST_NOTIFICATIONS
    if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(permission)!=PackageManager.PERMISSION_GRANTED &&
        (!prefs.getBoolean("askedNotifications",false) || interactive && shouldShowRequestPermissionRationale(permission))){
        prefs.edit().putBoolean("askedNotifications",true).apply()
        requestPermissions(arrayOf(permission),77)
    }else if(interactive){
        val manager=getSystemService(NotificationManager::class.java)
        val intent=if(manager.areNotificationsEnabled() && AlarmMedia.channel(this).importance==NotificationManager.IMPORTANCE_NONE)
            Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_CHANNEL_ID,AlarmMedia.CHANNEL)
        else Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
        startActivity(intent.putExtra(Settings.EXTRA_APP_PACKAGE,packageName))
    }
}
private fun Main.editAlarm(alarm:Bell?){
    AlarmEditor.open(this,alarm)
}
