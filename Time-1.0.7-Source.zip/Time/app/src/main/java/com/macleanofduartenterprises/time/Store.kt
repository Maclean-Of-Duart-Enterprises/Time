package com.macleanofduartenterprises.time

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.SystemClock
import android.util.Base64
import com.example.util.simpletimetracker.domain.record.mapper.RangeMapper
import com.example.util.simpletimetracker.domain.record.model.*
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.time.ZoneId
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class Guard(context:Context) {
    private val p=context.getSharedPreferences("admin",0)
    var unlocked=false
        private set
    val locked get()=p.getBoolean("enabled",false)
    fun check(){require(!locked || unlocked){"Unlock the admin panel first."}}
    private fun derive(pin:String,salt:ByteArray):ByteArray {
        val spec=PBEKeySpec(pin.toCharArray(),salt,120000,256)
        return try{SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded}finally{spec.clearPassword()}
    }
    fun enable(pin:String){
        check();require(pin.matches(Regex("[0-9]{6,12}"))){"Choose a PIN of 6–12 digits."}
        val salt=ByteArray(16).apply{SecureRandom().nextBytes(this)}
        require(p.edit().putString("salt",Base64.encodeToString(salt,2)).putString("hash",Base64.encodeToString(derive(pin,salt),2)).putBoolean("enabled",true).remove("retry").remove("tries").commit())
        unlocked=false
    }
    fun unlock(pin:String){ verifyPin(pin);unlocked=true }
    fun verifyPin(pin:String) {
        val wait=p.getLong("retry",0)-System.currentTimeMillis()
        require(wait<=0){"Try again in "+((wait+999)/1000)+" seconds."}
        val ok=MessageDigest.isEqual(derive(pin,Base64.decode(p.getString("salt",""),2)),Base64.decode(p.getString("hash",""),2))
        if(!ok){
            val n=p.getInt("tries",0)+1
            p.edit().putInt("tries",n).putLong("retry",if(n>=5)System.currentTimeMillis()+30000 else 0).commit()
            throw IllegalArgumentException("Incorrect PIN.")
        }
        p.edit().remove("retry").remove("tries").apply()
    }
    fun leave(){unlocked=false}
    fun disable(){check();require(p.edit().clear().commit());leave()}
}
class Store(context:Context,val guard:Guard):SQLiteOpenHelper(context,"time.db",null,4) {
    override fun onConfigure(db:SQLiteDatabase){db.setForeignKeyConstraintsEnabled(true)}
    override fun onCreate(db:SQLiteDatabase){
        db.execSQL("CREATE TABLE person(id INTEGER PRIMARY KEY,name TEXT NOT NULL,employee TEXT NOT NULL,business TEXT NOT NULL,fields TEXT NOT NULL)")
        db.execSQL("CREATE UNIQUE INDEX mode_id ON person(business,employee) WHERE employee!=''")
        db.execSQL("CREATE TABLE shift(id INTEGER PRIMARY KEY,person INTEGER NOT NULL REFERENCES person(id),start INTEGER NOT NULL,finish INTEGER,zone TEXT NOT NULL,note TEXT NOT NULL,factor TEXT NOT NULL DEFAULT '1')")
        db.execSQL("CREATE UNIQUE INDEX one_live ON shift(person) WHERE finish IS NULL")
        db.execSQL("CREATE INDEX history ON shift(person,start)")
        db.execSQL("CREATE TABLE pause(id INTEGER PRIMARY KEY,shift INTEGER NOT NULL REFERENCES shift(id) ON DELETE CASCADE,start INTEGER NOT NULL,finish INTEGER)")
        db.execSQL("CREATE UNIQUE INDEX one_pause ON pause(shift) WHERE finish IS NULL")
        createJobs(db)
        createSetup(db)
    }
    private fun createJobs(db:SQLiteDatabase){
        db.execSQL("CREATE TABLE job(id INTEGER PRIMARY KEY,name TEXT NOT NULL,code TEXT NOT NULL,fields TEXT NOT NULL,factor TEXT NOT NULL,archived INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE UNIQUE INDEX job_code ON job(code COLLATE NOCASE) WHERE code!=''")
        db.execSQL("ALTER TABLE shift ADD COLUMN job INTEGER REFERENCES job(id)")
    }
    private fun createSetup(db:SQLiteDatabase){
        db.execSQL("CREATE TABLE appearance(id INTEGER PRIMARY KEY CHECK(id=1),theme TEXT NOT NULL,face TEXT NOT NULL,hours TEXT NOT NULL,seconds INTEGER NOT NULL,opening_page TEXT NOT NULL DEFAULT 'clock')")
        db.execSQL("CREATE TABLE employee_file(person INTEGER NOT NULL REFERENCES person(id),name TEXT NOT NULL,mime TEXT NOT NULL,content BLOB NOT NULL,PRIMARY KEY(person,name))")
    }
    override fun onUpgrade(db:SQLiteDatabase,old:Int,new:Int){
        if(old<2)createJobs(db)
        if(old<3)createSetup(db)
        else if(old<4)db.execSQL("ALTER TABLE appearance ADD COLUMN opening_page TEXT NOT NULL DEFAULT 'clock'")
    }
    fun appearance()=query("SELECT theme,face,hours,seconds,opening_page FROM appearance WHERE id=1"){
        Appearance(it.getString(0),it.getString(1),it.getString(2),it.getInt(3)!=0,it.getString(4))
    }.singleOrNull()?:Appearance()
    fun saveAppearance(a:Appearance){
        writableDatabase.execSQL("INSERT OR REPLACE INTO appearance(id,theme,face,hours,seconds,opening_page) VALUES(1,?,?,?,?,?)",arrayOf(a.theme,a.face,a.hourFormat,if(a.seconds)1 else 0,a.openingPage))
    }
    fun employeeFiles(person:Long)=query("SELECT name FROM employee_file WHERE person=? ORDER BY name",person){it.getString(0)}
    fun employeeFile(person:Long,name:String):Pair<String,ByteArray>{
        val (mime,size)=query("SELECT mime,length(content) FROM employee_file WHERE person=? AND name=?",person,name){it.getString(0) to it.getInt(1)}.single()
        val bytes=java.io.ByteArrayOutputStream(size)
        while(bytes.size()<size){
            val chunk=query("SELECT substr(content,?,262144) FROM employee_file WHERE person=? AND name=?",bytes.size()+1,person,name){it.getBlob(0)}.single()
            check(chunk.isNotEmpty());bytes.write(chunk)
        }
        return mime to bytes.toByteArray()
    }
    data class SetupResult(val selected:Long?,val merged:Map<Long,Long>)
    fun applySetup(setup:EmployeeSetup,pin:String?,trustedKey:String?):SetupResult=transaction{
        guard.leave()
        if(setup.signature!=null)setup.signature.verify(trustedKey)
        else if(guard.locked)guard.verifyPin(requireNotNull(setup.password?:pin){"Enter the admin PIN to apply this file."})
        val merged=mutableMapOf<Long,Long>()
        val peopleIds=importSetupWorkers(setup.workers.map{it.profile},merged)
        mergeJobs(setup.jobs)
        val jobsByCode=if(setup.addresses.any{it.jobCode!=null})jobs().associateBy{it.code.lowercase(java.util.Locale.ROOT)} else emptyMap()
        val workersById=if(setup.addresses.any{it.employee!=null})people().associateBy{it.business to it.employee} else emptyMap()
        for(address in setup.addresses){
            if(address.jobCode!=null){
                val job=jobsByCode[address.jobCode.lowercase(java.util.Locale.ROOT)]?:error("Unknown job code in addresses: "+address.jobCode)
                writeJob(job.copy(fields=job.otherFields+("Site address" to address.value)))
            }else{
                val worker=workersById[address.business to address.employee]?:error("Unknown employee in addresses.")
                save(worker.copy(fields=worker.fields.filterKeys{!it.equals("Address",true)}+("Address" to address.value)))
            }
        }
        setup.workers.zip(peopleIds).forEach{(worker,id)->
            for(file in worker.files){
                writableDatabase.execSQL("INSERT OR REPLACE INTO employee_file(person,name,mime,content) VALUES(?,?,?,?)",arrayOf(id,file.name,file.mime,file.bytes))
            }
        }
        setup.settings?.let{saveAppearance(it.applyTo(appearance()))}
        SetupResult(peopleIds.singleOrNull(),merged)
    }
    private fun <T> query(sql:String,vararg args:Any,read:(Cursor)->T):List<T> =
        readableDatabase.rawQuery(sql,args.map(Any::toString).toTypedArray()).use{c->buildList{while(c.moveToNext())add(read(c))}}
    private fun <T> transaction(block:()->T):T {
        val db=writableDatabase; db.beginTransaction()
        return try{block().also{db.setTransactionSuccessful()}}finally{db.endTransaction()}
    }
    fun people()=query("SELECT id,name,employee,business,fields FROM person ORDER BY name COLLATE NOCASE,id"){c->
        val f=JSONObject(c.getString(4));Person(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),f.keys().asSequence().associateWith{f.getString(it)})
    }
    private fun fieldJson(fields:Map<String,String>):String{
        val json=JSONObject(fields).toString()
        require(json.toByteArray(Charsets.UTF_8).size<=1000000){"A profile’s custom fields exceed 1 MB."}
        return json
    }
    private fun save(p:Person):Long {
        p.checked()
        val v=ContentValues().apply{put("name",p.name);put("employee",p.employee);put("business",p.business);put("fields",fieldJson(p.fields))}
        return if(p.id==0L)writableDatabase.insertOrThrow("person",null,v) else {
            require(writableDatabase.update("person",v,"id=?",arrayOf(p.id.toString()))==1);p.id
        }
    }
    fun edit(p:Person):Long=transaction{guard.check();save(p)}
    fun importAll(profiles:List<Person>)=transaction {guard.check();mergePeople(profiles)}
    private fun mergePeople(profiles:List<Person>):List<Long> {
        val existing=people()
        val touched=mutableSetOf<Long>();val newKeys=mutableSetOf<Pair<String,String>>()
        return profiles.map{p->
            val within=existing.filter{it.business==p.business}
            val matches=if(p.employee.isNotEmpty())within.filter{it.employee==p.employee} else within.filter{it.name.equals(p.name,true)}
            require(matches.size<=1){"Ambiguous worker "+p.name+". Supply the MODE employee ID."}
            val found=matches.singleOrNull()
            val unique=p.business to (if(p.employee.isEmpty())"name:"+p.name.lowercase() else "id:"+p.employee)
            require(newKeys.add(unique) && (found==null || touched.add(found.id))){"Duplicate profile in file: "+p.name}
            val updated=found?.fields.orEmpty().filterKeys{key->p.fields.keys.none{Csv.head(it)==Csv.head(key)}}+p.fields
            save(p.copy(id=found?.id?:0,employee=p.employee.ifEmpty{found?.employee.orEmpty()},fields=updated))
        }
    }
    private fun importSetupWorkers(profiles:List<Person>,merged:MutableMap<Long,Long>):List<Long>{
        val existing=people()
        val claimed=mutableSetOf<Long>()
        val names=mutableSetOf<Pair<String,String>>()
        val planned=profiles.map{p->
            val matches=setupMatches(p,existing)
            require(names.add(p.business to workerName(p.name)) && matches.all{claimed.add(it.id)}){
                "Two entries in the setup file refer to the same employee."
            }
            p to matches
        }
        return planned.map{(p,matches)->
            val keep=matches.firstOrNull()
            if(keep!=null && matches.size>1){
                val active=matches.count{person->countRows("SELECT COUNT(*) FROM shift WHERE person=? AND finish IS NULL",person.id)>0}
                require(active<=1){"Clock out one of the duplicate employee records before combining two running shifts."}
                for(other in matches.drop(1)){
                    mergeWorkerHistory(other.id,keep.id)
                    merged[other.id]=keep.id
                }
            }
            save(p.copy(id=keep?.id?:0,employee=p.employee.ifBlank{matches.firstOrNull{it.employee.isNotBlank()}?.employee.orEmpty()},
                business=p.business.ifBlank{matches.firstOrNull{it.business.isNotBlank()}?.business.orEmpty()}))
        }
    }
    private fun mergeWorkerHistory(source:Long,target:Long){
        val db=writableDatabase
        db.execSQL("UPDATE shift SET person=? WHERE person=?",arrayOf(target,source))
        val used=employeeFiles(target).toMutableSet()
        for(name in employeeFiles(source)){
            var destination=name
            if(name in used){
                val same=countRows("SELECT COUNT(*) FROM employee_file a JOIN employee_file b ON a.name=b.name AND a.mime=b.mime AND a.content=b.content WHERE a.person=? AND b.person=? AND a.name=?",source,target,name)>0
                if(same)continue
                val dot=name.lastIndexOf('.').takeIf{it>0}?:name.length
                var n=2
                do{destination=name.take(dot)+" ("+(n++)+")"+name.substring(dot)}while(destination in used)
            }
            db.execSQL("UPDATE employee_file SET person=?,name=? WHERE person=? AND name=?",arrayOf(target,destination,source,name))
            used.add(destination)
        }
        db.delete("employee_file","person=?",arrayOf(source.toString()))
        check(db.delete("person","id=?",arrayOf(source.toString()))==1)
    }
    private fun countRows(sql:String,vararg args:Any)=query(sql,*args){it.getLong(0)}.single()
    data class WorkerHistory(val shifts:Long,val running:Long,val files:Long)
    fun workerHistory(id:Long)=WorkerHistory(countRows("SELECT COUNT(*) FROM shift WHERE person=?",id),
        countRows("SELECT COUNT(*) FROM shift WHERE person=? AND finish IS NULL",id),
        countRows("SELECT COUNT(*) FROM employee_file WHERE person=?",id))
    fun deleteWorker(worker:Person,expected:WorkerHistory)=transaction{
        guard.check()
        require(people().find{it.id==worker.id}==worker && workerHistory(worker.id)==expected){"Employee records changed. Review the deletion again."}
        val args=arrayOf(worker.id.toString())
        writableDatabase.delete("employee_file","person=?",args)
        writableDatabase.delete("shift","person=?",args)
        check(writableDatabase.delete("person","id=?",args)==1)
    }
    fun deleteJob(job:Job)=transaction{
        guard.check()
        require(jobs().find{it.id==job.id}==job){"The job changed. Open it again."}
        writableDatabase.execSQL("UPDATE shift SET job=NULL WHERE job=?",arrayOf(job.id))
        check(writableDatabase.delete("job","id=?",arrayOf(job.id.toString()))==1)
    }
    fun jobs()=query("SELECT id,name,code,fields,factor,archived FROM job ORDER BY archived,name COLLATE NOCASE,id"){c->
        val f=JSONObject(c.getString(3));Job(c.getLong(0),c.getString(1),c.getString(2),f.keys().asSequence().associateWith{f.getString(it)},c.getString(4),c.getInt(5)!=0)
    }
    fun saveJob(j:Job):Long{guard.check();return writeJob(j)}
    private fun writeJob(j:Job):Long{
        j.checked()
        val v=ContentValues().apply{put("name",j.name);put("code",j.code);put("fields",fieldJson(j.fields));put("factor",j.factor);put("archived",if(j.archived)1 else 0)}
        return if(j.id==0L)writableDatabase.insertOrThrow("job",null,v)else{
            require(writableDatabase.update("job",v,"id=?",arrayOf(j.id.toString()))==1);j.id
        }
    }
    fun importJobs(imports:List<ImportedJob>)=transaction{guard.check();mergeJobs(imports)}
    private fun mergeJobs(imports:List<ImportedJob>){
        val original=jobs();val seen=mutableSetOf<String>();val ids=mutableSetOf<Long>()
        for(item in imports){
            val j=item.job
            val matches=if(j.code.isBlank())original.filter{it.name.equals(j.name,true)}else original.filter{it.code.equals(j.code,true)}
            require(matches.size<=1){"Ambiguous job name. Include a job code."}
            val old=matches.singleOrNull()
            require(seen.add(if(j.code.isBlank())"name:"+j.name.lowercase() else "code:"+j.code.lowercase()) && (old==null || ids.add(old.id))){"Duplicate job in file: "+j.name}
            val merged=old?.fields.orEmpty().filterKeys{k->j.fields.keys.none{Csv.head(it)==Csv.head(k) || isAddress(it) && isAddress(k)}}+j.fields
            writeJob(j.copy(id=old?.id?:0,code=j.code.ifBlank{old?.code.orEmpty()},fields=merged,factor=if(item.hasFactor)j.factor else old?.factor?:j.factor,archived=old?.archived?:false))
        }
    }
    data class Live(val shift:Long,val rec:RunningRecord,val paused:Long?,val unpaidMs:Long)
    fun live(person:Long):Live?=query("SELECT id,start,note FROM shift WHERE person=? AND finish IS NULL",person){c->
        val id=c.getLong(0)
        val pauses=query("SELECT start,finish FROM pause WHERE shift=? ORDER BY start",id){it.getLong(0) to if(it.isNull(1))null else it.getLong(1)}
        Live(id,RunningRecord(person,c.getLong(1),c.getString(2),emptyList()),pauses.lastOrNull()?.takeIf{it.second==null}?.first,pauses.sumOf{(a,b)->if(b==null)0L else b-a})
    }.singleOrNull()
    fun start(person:Long,note:String,inputFactor:String,jobId:Long=0)=transaction{
        val job=if(jobId==0L)null else jobs().singleOrNull{it.id==jobId && !it.archived}?:error("Select an active job.")
        val factor=if(guard.locked)job?.factor?:"1" else inputFactor
        val description=listOfNotNull(job?.let{"Job: "+it.caption},note.takeIf{it.isNotBlank()}).joinToString("\n")
        val rate=factor.toBigDecimalOrNull();require(rate!=null && rate>=java.math.BigDecimal("0.01") && rate<=java.math.BigDecimal.TEN && rate.scale() in 0..4){"Choose a multiplier from 0.01 to 10 (up to four decimal places)."}
        require(description.length<=4000){"Use 4,000 characters or fewer."}
        val now=System.currentTimeMillis()/1000*1000
        val last=query("SELECT MAX(finish) FROM shift WHERE person=?",person){it.getLong(0)}.first()
        require(now>=last){"The device clock is earlier than the last shift."}
        writableDatabase.execSQL("INSERT INTO shift(person,start,zone,note,factor,job) VALUES(?,?,?,?,?,?)",arrayOf(person,now,ZoneId.systemDefault().id,description,rate.toPlainString(),job?.id))
    }
    fun punch(person:Long,stop:Boolean)=transaction{
        val live=live(person)?:error("No running shift.")
        val r=RangeMapper().mapRunningRecordToRecord(live.rec);val now=r.timeEnded
        require(now>=r.timeStarted && (live.paused==null || now>=live.paused)){"The device clock moved backwards."}
        val previous=query("SELECT MAX(finish) FROM pause WHERE shift=?",live.shift){it.getLong(0)}.first()
        require(now>=previous){"The device clock is earlier than the previous break."}
        if(stop)require(r.duration-live.unpaidMs-(live.paused?.let{now-it}?:0)>0){"Record at least one paid second first."}
        if(live.paused!=null)writableDatabase.execSQL("UPDATE pause SET finish=? WHERE shift=? AND finish IS NULL",arrayOf(now,live.shift))
        else if(!stop)writableDatabase.execSQL("INSERT INTO pause(shift,start) VALUES(?,?)",arrayOf(live.shift,now))
        if(stop)writableDatabase.execSQL("UPDATE shift SET finish=? WHERE id=?",arrayOf(now,live.shift))
    }
    fun saveShift(person:Long,previous:Shift?,start:Long,end:Long,zone:ZoneId,breaks:List<Range>,notes:String,jobId:Long?)=transaction {
        guard.check()
        require(end>start && end<=System.currentTimeMillis()){"A completed shift needs a clock-out after clock-in and no later than now."}
        val sorted=breaks.sortedBy{it.timeStarted}
        var last=start
        for(interval in sorted){
            require(interval.timeStarted>=last && interval.timeEnded>=interval.timeStarted && interval.timeEnded<=end){"Breaks must be inside the shift and cannot overlap."}
            last=interval.timeEnded
        }
        require(end-start>sorted.sumOf{it.duration}){"Record at least one paid second."}
        val id=previous?.record?.id?:0
        val collision=query("SELECT id FROM shift WHERE person=? AND id!=? AND start<? AND (finish IS NULL OR finish>?) LIMIT 1",person,id,end,start){it.getLong(0)}
        require(collision.isEmpty()){"This overlaps another shift for this worker."}
        if(previous!=null){
            require(shifts(person).firstOrNull{it.record.id==id}==previous){"This shift changed. Reopen it before editing."}
        }
        val job=jobId?.let{key->jobs().singleOrNull{it.id==key && !it.archived}?:error("Choose an active job.")}
        val description=if(previous==null && job!=null) listOf("Job: "+job.caption,notes).filter{it.isNotBlank()}.joinToString("\n") else notes
        require(description.length<=4000){"Use 4,000 characters or fewer in the shift notes."}
        val values=ContentValues().apply{put("start",start);put("finish",end);put("zone",zone.id);put("note",description)}
        val db=writableDatabase
        val saved=if(previous==null){
            values.put("person",person);values.put("factor",job?.factor?:"1");job?.let{values.put("job",it.id)}
            db.insertOrThrow("shift",null,values)
        }else{
            check(db.update("shift",values,"id=? AND person=? AND finish IS NOT NULL",arrayOf(id.toString(),person.toString()))==1)
            db.delete("pause","shift=?",arrayOf(id.toString()));id
        }
        for(interval in sorted)db.execSQL("INSERT INTO pause(shift,start,finish) VALUES(?,?,?)",arrayOf(saved,interval.timeStarted,interval.timeEnded))
        saved
    }
    private fun removeCompleted(person:Long,id:Long){
        val changed=writableDatabase.delete("shift","person=? AND id=? AND finish IS NOT NULL",arrayOf(person.toString(),id.toString()))
        check(changed==1){"The shift changed. Reopen the timecard."}
    }

    fun deleteShift(person:Long,expected:Shift)=transaction{
        guard.check()
        check(shifts(person).firstOrNull{it.record.id==expected.record.id}==expected){"This shift changed. Review it before deleting."}
        removeCompleted(person,expected.record.id)
    }

    fun deleteTimecard(person:Long,from:java.time.LocalDate,to:java.time.LocalDate,expected:List<Shift>)=transaction{
        guard.check()
        require(from<=to && expected.isNotEmpty()){"Choose a nonempty timecard."}
        val actual=shifts(person).filter{Cards.intersects(it,from,to)}
        check(actual==expected){"This timecard changed. Review its totals before deleting."}
        val db=writableDatabase
        for(shift in actual){
            val id=shift.record.id
            // A long shift can contribute payroll rows on both sides of the period.
            // Keep each outside row's original work date and its portion of each break.
            val retained=Cards.segments(shift).filter{it.date !in from..to}.toList()
            if(retained.isEmpty()){
                removeCompleted(person,id)
                continue
            }
            db.delete("pause","shift=?",arrayOf(id.toString()))
            for((index,part) in retained.withIndex()){
                val span=part.span
                val partId=if(index==0){
                    val values=ContentValues().apply{put("start",span.timeStarted);put("finish",span.timeEnded)}
                    check(db.update("shift",values,"id=? AND person=? AND finish IS NOT NULL",arrayOf(id.toString(),person.toString()))==1)
                    id
                }else db.compileStatement("INSERT INTO shift(person,start,finish,zone,note,factor,job) SELECT person,?,?,zone,note,factor,job FROM shift WHERE id=? AND person=?").use{insert->
                    insert.bindLong(1,span.timeStarted);insert.bindLong(2,span.timeEnded);insert.bindLong(3,id);insert.bindLong(4,person)
                    insert.executeInsert().also{check(it>0)}
                }
                for(pause in shift.breaks){
                    val left=maxOf(pause.timeStarted,span.timeStarted)
                    val right=minOf(pause.timeEnded,span.timeEnded)
                    if(left<right)db.execSQL("INSERT INTO pause(shift,start,finish) VALUES(?,?,?)",arrayOf(partId,left,right))
                }
            }
        }
    }
    fun shifts(person:Long):List<Shift>{
        val pauses=query("SELECT p.shift,p.start,p.finish FROM pause p JOIN shift s ON p.shift=s.id WHERE s.person=? AND s.finish IS NOT NULL",person){it.getLong(0) to Range(it.getLong(1),it.getLong(2))}.groupBy({it.first},{it.second})
        return query("SELECT id,start,finish,note,zone,factor FROM shift WHERE person=? AND finish IS NOT NULL ORDER BY start DESC",person){c->
            val r=Record(c.getLong(0),person,c.getLong(1),c.getLong(2),c.getString(3),emptyList())
            Shift(r,ZoneId.of(c.getString(4)),pauses[r.id].orEmpty(),c.getString(5))
        }
    }
}
