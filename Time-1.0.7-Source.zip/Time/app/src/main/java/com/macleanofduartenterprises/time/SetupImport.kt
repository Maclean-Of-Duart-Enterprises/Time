package com.macleanofduartenterprises.time

import android.net.Uri
import android.text.InputType
import android.widget.LinearLayout
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.Base64

private const val SENDER="trusted_setup_public_key"
fun Main.trustedSenderControls(parent:LinearLayout){
    val current=getSharedPreferences("admin",0).getString(SENDER,null)
    if(current!=null){
        val fingerprint=MessageDigest.getInstance("SHA-256").digest(SetupSignature.publicKey(current).encoded).joinToString(":"){"%02X".format(it)}
        label(parent,"Setup sender SHA-256\n"+fingerprint,14,muted)
    }
    action(parent,if(current==null)"Trust setup sender" else "Replace trusted setup sender"){
        guard.check()
        val f=form()
        val key=field(f,"Sender’s public key (PEM or Base64)",type=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)
        popup("Trust setup sender",f,"Trust"){
            guard.check()
            val parsed=SetupSignature.publicKey(key.text.toString())
            check(getSharedPreferences("admin",0).edit().putString(SENDER,Base64.getEncoder().encodeToString(parsed.encoded)).commit())
            draw()
        }
    }
    action(parent,"Show this device’s sender key"){
        guard.check();showSenderKey()
    }
    action(parent,"Add admin PIN to setup JSON"){
        guard.check()
        startActivityForResult(android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(android.content.Intent.CATEGORY_OPENABLE).setType("*/*"),56)
    }
    action(parent,"Sign employee setup file"){
        guard.check()
        startActivityForResult(android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(android.content.Intent.CATEGORY_OPENABLE).setType("*/*"),55)
    }
    if(current!=null)action(parent,"Remove trusted sender"){
        confirm("Remove trusted sender?","Files signed by this sender will require a new trust setup.","Remove"){
            guard.check();check(getSharedPreferences("admin",0).edit().remove(SENDER).commit());draw()
        }
    }
}
fun Main.readSetupFile(uri:Uri,ready:(ByteArray,EmployeeSetup)->Unit){
    guard.leave()
    kotlin.concurrent.thread{
        val result=runCatching{
            val input=contentResolver.openInputStream(uri)?:error("Unable to read this file.")
            val bytes=input.use{stream->
                val data=ByteArrayOutputStream();val buffer=ByteArray(16384)
                while(true){
                    val count=stream.read(buffer);if(count<0)break
                    require(data.size()+count<=SetupCodec.MAX_BYTES){"Setup files must be at most 16 MiB."}
                    data.write(buffer,0,count)
                }
                data.toByteArray()
            }
            bytes to SetupCodec.read(bytes)
        }
        runOnUiThread{if(!isFinishing && !isDestroyed)attempt{
            val (bytes,setup)=result.getOrThrow();ready(bytes,setup)
        }}
    }
}

fun Main.reviewSetup(uri:Uri)=readSetupFile(uri){_,setup->
    fun sender()=getSharedPreferences("admin",0).getString(SENDER,null)
    fun apply(pin:String?){
        val result=try{db.applySetup(setup,pin,sender())}finally{guard.leave()}
        val edit=prefs.edit()
        for((old,kept) in result.merged){
            val job=prefs.getLong("job-for-"+old,0)
            if(job!=0L && !prefs.contains("job-for-"+kept))edit.putLong("job-for-"+kept,job)
            edit.remove("job-for-"+old)
        }
        val selected=result.selected?:result.merged[prefs.getLong("person",0)]
        if(selected!=null)edit.putLong("person",selected)
        edit.apply()
        refreshAppearance();note("Employee setup applied.")
    }
    if(!guard.locked || setup.signature!=null || setup.password!=null){
        apply(null)
    }else{
        val box=form()
        label(box,setup.summary(),16)
        val pin=field(box,"This file has no authorization. Enter the admin PIN.","",InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        popup("Apply employee setup?",box,"Apply"){apply(pin.text.toString())}
    }
}

fun Main.prepareSetupPin(uri:Uri)=readSetupFile(uri){bytes,setup->
    require(setup.signature==null){"Choose the unsigned setup file from MODE Handyman."}
    val box=form()
    label(box,setup.summary(),16)
    label(box,"Enter the existing PIN for the employee’s Time app. Anyone with the saved JSON can read that PIN.",15,muted)
    val type=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
    val pin=field(box,"Employee device admin PIN","",type)
    val repeat=field(box,"Confirm PIN","",type)
    popup("Add admin PIN to setup JSON",box,"Save copy"){
        require(pin.text.toString()==repeat.text.toString()){"PINs do not match."}
        val output=SetupCodec.withPassword(bytes,pin.text.toString())
        val employee=setup.workers.singleOrNull()?.profile?.name?.replace(Regex("[^\\p{L}\\p{N}._-]+"),"-")?.take(64)
        exportBytes("Time-setup-"+(employee?:"employees")+"-authorized.json","application/json",output)
    }
}
