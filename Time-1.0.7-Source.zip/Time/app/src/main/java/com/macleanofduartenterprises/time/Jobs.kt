package com.macleanofduartenterprises.time

import android.content.Intent
import android.text.InputType
import java.math.BigDecimal

data class Job(val id:Long=0,val name:String,val code:String="",val fields:Map<String,String> = emptyMap(),val factor:String="1",val archived:Boolean=false){
    val address get()=fields.entries.firstOrNull{isAddress(it.key)}?.value.orEmpty()
    val otherFields get()=fields.filterKeys{!isAddress(it)}
    val caption get()=if(code.isEmpty())name else code+" · "+name
    fun checked():Job {
        require(name.isNotBlank() && name.length<=250 && code.length<=100){"Enter a job name up to 250 characters and a code up to 100 characters."}
        val n=factor.toBigDecimalOrNull()
        require(factor.matches(Regex("\\d+(\\.\\d{1,4})?")) && n!=null && n>=BigDecimal("0.01") && n<=BigDecimal.TEN){"Use a pay multiplier from 0.01 to 10."}
        require(fields.size<=90 && fields.all{(k,v)->k.isNotBlank() && k.length<=150 && v.length<=10000 && Csv.head(k) !in JobCsv.reserved} && fields.keys.distinctBy(Csv::head).size==fields.size){"Use unique custom labels other than job name, job code and multiplier."}
        return this
    }
}
fun isAddress(label:String)=Csv.head(label) in setOf("address","site_address","job_site_address","job_address")
fun canonicalJobFields(fields:Map<String,String>):Map<String,String>{
    val addresses=fields.filterKeys(::isAddress).values.filter(String::isNotBlank).distinct()
    require(addresses.size<=1){"Use one site address per job."}
    return fields.filterKeys{!isAddress(it)}+if(fields.keys.any(::isAddress))mapOf("Site address" to addresses.firstOrNull().orEmpty())else emptyMap()
}
data class ImportedJob(val job:Job,val hasFactor:Boolean)
object JobCsv {
    val reserved=setOf("name","job_name","job_code","multiplier")
    fun parse(raw:String):List<ImportedJob>{
        val rows=Csv.table(raw);val labels=rows.first().map{it.trim()}
        val keys=labels.map{Csv.head(it).let{k->if(k=="name")"job_name" else k}}
        require("job_name" in keys && keys.all{it.isNotBlank()} && keys.distinct().size==keys.size){"Use unique headers including job_name."}
        return rows.drop(1).mapIndexed{i,c->
            require(c.size<=keys.size){"Too many cells in row "+(i+2)}
            fun get(key:String)=c.getOrNull(keys.indexOf(key)).orEmpty().trim()
            val custom=labels.indices.filter{keys[it] !in reserved}.associate{labels[it] to c.getOrNull(it).orEmpty()}
            ImportedJob(Job(name=get("job_name"),code=get("job_code"),fields=canonicalJobFields(custom),factor=get("multiplier").ifBlank{"1"}).checked(),"multiplier" in keys)
        }
    }
    fun export(jobs:List<Job>):String {
        val labels=jobs.flatMap{it.fields.keys}.distinctBy(Csv::head)
        return Csv.row(listOf("job_name","job_code","multiplier")+labels)+jobs.joinToString(""){j->
            val m=j.fields.mapKeys{Csv.head(it.key)}
            Csv.row(listOf(j.name,j.code,j.factor)+labels.map{m[Csv.head(it)].orEmpty()})
        }
    }
}
fun Main.jobsScreen(admin:Boolean){
    if(admin)label(sheet,"Job profiles",20,ink,true)else heading("Job profiles")
    val canEdit=!guard.locked || admin && guard.unlocked
    val jobs=db.jobs()
    if(canEdit){
        val r=row(sheet);action(r,"Add job",true){editJob(null)};action(r,"Import job CSV"){
            guard.check();startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),53)
        }
        if(jobs.any{!it.archived})action(sheet,"Export active jobs CSV"){guard.check();export("Time-job-profiles.csv",JobCsv.export(jobs.filterNot{it.archived}))}
    }else label(sheet,"Jobs are read-only. Choose an active job on the Timecard tab before clocking in.",15,muted)
    val shown=jobs.filter{!it.archived || canEdit}
    if(shown.isEmpty())label(sheet,"No active jobs.",16,muted)
    shown.forEach{j->
        val b=card();label(b,j.caption,20,ink,true)
        label(b,(if(j.archived)"Archived  ·  " else "")+"Pay multiplier  ×"+j.factor,15,muted)
        if(j.address.isNotBlank()){
            val address=label(b,j.address,16,pine);address.setOnClickListener{openJobMap(j.address)}
            action(b,"Navigate to job site"){openJobMap(j.address)}
        }
        j.otherFields.forEach{(k,v)->label(b,k+"  ·  "+v,15)}
        if(canEdit){
            val r=row(b);action(r,"Edit job"){editJob(j)}
            action(r,if(j.archived)"Restore job" else "Archive job"){
                if(j.archived){db.saveJob(j.copy(archived=false));draw()}
                else confirm("Archive job?",j.caption+" will be removed from new shift choices. Existing shifts keep their job details.","Archive"){db.saveJob(j.copy(archived=true));draw()}
            }
            action(b,"Delete job"){
                confirm("Delete job?","Permanently delete "+j.caption+"? Existing timecards keep the recorded hours, job notes and pay multiplier.","Delete"){
                    db.deleteJob(j)
                    val edit=prefs.edit()
                    prefs.all.filter{(k,v)->k.startsWith("job-for-") && v==j.id}.keys.forEach{edit.remove(it)}
                    edit.apply();draw()
                }
            }
        }
    }
}
fun Main.editJob(old:Job?){
    guard.check();val b=form()
    val name=field(b,"Job name",old?.name.orEmpty());val code=field(b,"Job code (optional)",old?.code.orEmpty())
    val factor=field(b,"Default pay multiplier",old?.factor?:"1",InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
    val address=field(b,"Job site address",old?.address.orEmpty(),InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_POSTAL_ADDRESS)
    val custom=customFields(b,old?.otherFields.orEmpty())
    popup(if(old==null)"Add job" else "Edit job",b){
        val extra=custom()
        require(extra.keys.none(::isAddress)){"Enter the job site address in its address field."}
        val fields=extra+if(address.text.isNotBlank())mapOf("Site address" to address.text.toString().trim())else emptyMap()
        db.saveJob(Job(old?.id?:0,name.text.toString().trim(),code.text.toString().trim(),fields,factor.text.toString(),old?.archived?:false));draw()
    }
}
