package com.macleanofduartenterprises.time

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.text.InputType
import android.widget.*
import com.example.util.simpletimetracker.domain.record.model.Range
import java.time.*
import java.time.format.DateTimeFormatter

private val clockStamp = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss", java.util.Locale.ROOT)

private fun displayStamp(stamp: ZonedDateTime): String {
    val overlap = stamp.zone.rules.getValidOffsets(stamp.toLocalDateTime()).size > 1
    return stamp.format(clockStamp) + if (overlap) stamp.offset.toString() else ""
}

private fun readStamp(text: String, zone: ZoneId): ZonedDateTime {
    val value = text.trim().replace(' ', 'T')
    val offsetTime = runCatching { OffsetDateTime.parse(value) }.getOrNull()
    val local = offsetTime?.toLocalDateTime() ?: runCatching { LocalDateTime.parse(value) }
        .getOrElse { error("Enter the date and time as YYYY-MM-DD HH:MM or use the pickers.") }
    require(local.nano == 0) { "Enter times to the nearest second." }
    val offsets = zone.rules.getValidOffsets(local)
    require(offsets.isNotEmpty()) { "That local time is skipped by the daylight-saving change." }
    val offset = offsetTime?.offset ?: offsets.singleOrNull()
    require(offset != null && offset in offsets) {
        "For this repeated hour, add one of these UTC offsets to the time: " + offsets.joinToString()
    }
    return ZonedDateTime.ofStrict(local, offset, zone)
}

private fun Main.timestamp(parent:LinearLayout, title:String, initial:ZonedDateTime): () -> Long {
    val input=field(parent,title,displayStamp(initial),InputType.TYPE_CLASS_DATETIME)
    // DATETIME key listeners on some keyboards filter the space and the UTC offset.
    input.inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    input.setText(displayStamp(initial))
    val zone=initial.zone
    fun current()=readStamp(input.text.toString(),zone)
    val buttons=row(parent)
    action(buttons,"Choose date"){
        val value=runCatching{current()}.getOrDefault(initial)
        DatePickerDialog(this,{_,year,month,day->
            val local=LocalDate.of(year,month+1,day).atTime(value.toLocalTime())
            input.setText(displayStamp(ZonedDateTime.ofLocal(local,zone,value.offset)))
        },value.year,value.monthValue-1,value.dayOfMonth).show()
    }
    action(buttons,"Choose time"){
        val value=runCatching{current()}.getOrDefault(initial)
        TimePickerDialog(this,{_,hour,minute->
            input.setText(displayStamp(ZonedDateTime.ofLocal(value.toLocalDate().atTime(hour,minute),zone,value.offset)))
        },value.hour,value.minute,use24()).show()
    }
    return { current().toInstant().toEpochMilli() }
}

fun Main.openShiftEditor(worker:Person, previous:Shift?=null){
    if(guard.locked && !guard.unlocked){
        unlock{showShiftEditor(worker,previous)}
    }else showShiftEditor(worker,previous)
}

private fun Main.showShiftEditor(worker:Person, previous:Shift?){
    guard.check()
    val zone=previous?.zone?:ZoneId.systemDefault()
    val now=ZonedDateTime.now(zone).withNano(0)
    val selectedDate=now.toLocalDate().coerceIn(from,to)
    val defaultEnd=if(selectedDate==now.toLocalDate())now else selectedDate.atTime(17,0).atZone(zone)
    fun stamp(ms:Long)=Instant.ofEpochMilli(ms).atZone(zone)
    val start=previous?.record?.timeStarted?.let(::stamp)?:defaultEnd.minusHours(1)
    val finish=previous?.record?.timeEnded?.let(::stamp)?:defaultEnd
    val panel=form()
    label(panel,worker.name,19,ink,true)
    label(panel,zone.id,14,muted)
    val begin=timestamp(panel,"Clock in",start)
    val end=timestamp(panel,"Clock out",finish)
    val breaksBox=col(panel)
    val intervals=mutableListOf<Pair<()->Long,()->Long>>()
    fun addBreak(left:ZonedDateTime,right:ZonedDateTime){
        val box=card(breaksBox)
        val pair=timestamp(box,"Unpaid break starts",left) to timestamp(box,"Unpaid break ends",right)
        intervals.add(pair)
        action(box,"Remove break"){intervals.remove(pair);breaksBox.removeView(box)}
    }
    previous?.breaks?.forEach{addBreak(stamp(it.timeStarted),stamp(it.timeEnded))}
    action(panel,"Add unpaid break"){
        val first=begin()
        val last=end()
        require(last>first){"Clock-out must follow clock-in."}
        val length=minOf(1800000L,((last-first)/2000)*1000)
        val middle=first+((last-first-length)/2000)*1000
        addBreak(stamp(middle),stamp(middle+length))
    }
    val jobs=if(previous==null)db.jobs().filterNot{it.archived} else emptyList()
    var selectedJob:Spinner?=null
    if(jobs.isNotEmpty()){
        label(panel,"Job",14,muted,true)
        selectedJob=Spinner(this)
        selectedJob.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("Unassigned")+jobs.map{it.caption})
        selectedJob.setSelection(jobs.indexOfFirst{it.id==prefs.getLong("job-for-"+worker.id,0)}+1)
        panel.addView(selectedJob)
    }
    val notes=field(panel,"Shift notes",previous?.record?.comment.orEmpty(),InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)
    popup(if(previous==null)"Add manual shift" else "Edit shift",panel,"Save shift"){
        val startMs=begin()
        db.saveShift(worker.id,previous,startMs,end(),zone,intervals.map{Range(it.first(),it.second())},notes.text.toString(),
            selectedJob?.let{jobs.getOrNull(it.selectedItemPosition-1)?.id})
        val day=stamp(startMs).toLocalDate()
        if(day !in from..to){from=day.with(DayOfWeek.MONDAY);to=from.plusDays(6)}
        prefs.edit().putInt("historyPage",0).apply()
        draw()
        note("Shift saved.")
    }
    dialog?.setOnDismissListener{guard.leave()}
}
