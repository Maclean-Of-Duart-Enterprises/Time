package com.macleanofduartenterprises.time

import com.example.util.simpletimetracker.domain.record.model.Range
import com.example.util.simpletimetracker.domain.record.model.Record
import java.time.*
import java.time.format.DateTimeFormatter
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale

data class Person(val id:Long=0, val name:String, val employee:String="", val business:String="", val fields:Map<String,String> = emptyMap()) {
    fun checked():Person {
        require(name.isNotBlank() && name.length<=250) { "Enter a worker name (up to 250 characters)." }
        require(listOf(employee,business).all { it.isEmpty() || it.toLongOrNull()?.let { n -> n>0 && n.toString()==it }==true }) { "Use the numeric ID from MODE Handyman, or leave it blank." }
        require(fields.size<=90 && fields.all { (k,v)->k.isNotBlank() && k.length<=150 && v.length<=10000 && Csv.head(k) !in Csv.reserved }) { "Custom fields need unique labels other than the worker name and MODE ID columns." }
        require(fields.keys.distinctBy(Csv::head).size==fields.size) { "Two custom field labels match." }
        return this
    }
}
data class Shift(val record:Record,val zone:ZoneId,val breaks:List<Range>,val factor:String="1")
object Csv {
    val reserved=setOf("employee_name","name","worker_name","employee_id","business_profile_id")
    fun head(s:String)=s.trim().lowercase(Locale.ROOT).replace(Regex("[\\s-]+"),"_")
    fun row(values:List<String>)=values.joinToString(",") { "\""+it.replace("\"","\"\"")+"\"" }+"\r\n"
    fun table(raw:String):List<List<String>> {
        require(raw.length<=2_000_000) { "Profile CSV exceeds 2 million characters." }
        val text=raw.removePrefix("\uFEFF")
        val delimiters=linkedMapOf(',' to 0,';' to 0,'\t' to 0)
        var inside=false
        for(c in text){
            if(c=='"')inside=!inside
            else if(!inside){
                if(c=='\n' || c=='\r')break
                if(c in delimiters)delimiters[c]=delimiters.getValue(c)+1
            }
        }
        val sep=delimiters.maxBy{it.value}.key
        val rows=mutableListOf<List<String>>(); var cells=mutableListOf<String>(); val field=StringBuilder()
        var quoted=false; var closed=false; var i=0
        fun cell(){cells+=field.toString();field.setLength(0);closed=false;require(cells.size<=95){"Too many columns."}}
        fun end(){cell();if(cells.any{it.isNotBlank()})rows+=cells;cells=mutableListOf();require(rows.size<=5001){"Limit imports to 5,000 profiles."}}
        while(i<text.length){
            val c=text[i++]
            if(quoted){
                if(c!='"')field.append(c)
                else if(i<text.length && text[i]=='"'){field.append('"');i++}else{quoted=false;closed=true}
            }else when(c){
                '"'->{require(field.isEmpty() && !closed){"Unexpected quote in CSV."};quoted=true}
                sep->cell()
                '\r','\n'->{end();if(c=='\r' && i<text.length && text[i]=='\n')i++}
                else->{require(!closed){"Unexpected text after closing quote."};field.append(c)}
            }
        }
        require(!quoted){"Unclosed CSV quote."}
        if(field.isNotEmpty() || cells.isNotEmpty() || closed)end()
        require(rows.size>=2){"Include a header and at least one worker."}
        return rows
    }
    fun parse(raw:String):List<Person> {
        val rows=table(raw)
        val headers=rows.first().map{it.trim()}
        val keys=headers.map{when(val k=head(it)){"name","worker_name"->"employee_name";else->k}}
        require(keys.all{it.isNotBlank()} && keys.distinct().size==keys.size && "employee_name" in keys){"Provide unique column names and an employee_name column."}
        return rows.drop(1).mapIndexed { ix, values ->
            try {
                require(values.size<=keys.size){"Extra column. Quote text containing commas."}
                fun value(k:String)=values.getOrNull(keys.indexOf(k)).orEmpty().trim()
                val custom=headers.indices.filter{keys[it] !in reserved}.associate{headers[it] to values.getOrNull(it).orEmpty()}
                Person(name=value("employee_name"),employee=value("employee_id"),business=value("business_profile_id"),fields=custom).checked()
            }catch(e:IllegalArgumentException){throw IllegalArgumentException("Row "+(ix+2)+": "+e.message)}
        }
    }
    fun profiles(people:List<Person>):String {
        val labels=people.flatMap{it.fields.keys}.distinctBy(::head)
        return row(listOf("employee_name","employee_id","business_profile_id")+labels)+people.joinToString(""){p->
            val m=p.fields.mapKeys{head(it.key)}
            row(listOf(p.name,p.employee,p.business)+labels.map{m[head(it)].orEmpty()})
        }
    }
}
object Cards {
    private val fmt=DateTimeFormatter.ofPattern("HH:mm:ss",Locale.ROOT)
    fun duration(seconds:Long)=String.format(Locale.ROOT,"%d:%02d:%02d",seconds/3600,seconds/60%60,seconds%60)
    fun minutes(seconds:Long)=BigDecimal.valueOf(seconds).divide(BigDecimal.valueOf(60),6,RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
    data class Segment(val date:LocalDate,val start:String,val end:String,val unpaid:Long,val paid:Long,val span:Range)
    fun intersects(s:Shift,from:LocalDate,to:LocalDate)=segments(s).any{it.date>=from && it.date<=to && it.paid>0}
    fun segments(s:Shift):Sequence<Segment> = sequence {
        val r=s.record
        var begin=Instant.ofEpochMilli(r.timeStarted).atZone(s.zone)
        val finish=Instant.ofEpochMilli(r.timeEnded).atZone(s.zone)
        // Keep ordinary overnight shifts on their clock-in date. Split very long shifts at midnight.
        while(begin<finish){
            val left=Duration.between(begin,finish).seconds
            val end=if(left<=86400)finish else minOf(begin.plusHours(24),begin.toLocalDate().plusDays(1).atStartOfDay(s.zone))
            val date=begin.toLocalDate()
            val span=Range(begin.toInstant().toEpochMilli(),end.toInstant().toEpochMilli())
            val unpaid=s.breaks.filter{it.isOverlappingWith(span)}.sumOf{(minOf(it.timeEnded,span.timeEnded)-maxOf(it.timeStarted,span.timeStarted))/1000}
            val paid=span.duration/1000-unpaid
            val clocks=begin.offset==end.offset && span.duration<86400000L &&
                s.zone.rules.getValidOffsets(begin.toLocalDateTime()).size==1 && s.zone.rules.getValidOffsets(end.toLocalDateTime()).size==1
            yield(Segment(date,if(clocks)fmt.format(begin)else "",if(clocks)fmt.format(end)else "",unpaid,paid,span))
            begin=end
        }
    }
    fun export(person:Person, shifts:List<Shift>, from:LocalDate, to:LocalDate):String {
        require(!to.isBefore(from) && to.toEpochDay()-from.toEpochDay()<=366){"Choose a period of up to 367 days."}
        val csv=StringBuilder(Csv.row(listOf("employee_id","employee_name","business_profile_id","date","start","end","break_minutes","worked_seconds","multiplier","notes","period_start","period_end")))
        var count=0
        shifts.sortedBy{it.record.timeStarted}.forEach { s ->
            for(part in segments(s)){
                if(part.paid<=0 || part.date<from || part.date>to)continue
                csv.append(Csv.row(listOf(person.employee,person.name,person.business,part.date.toString(),part.start,part.end,minutes(part.unpaid),part.paid.toString(),s.factor,s.record.comment,from.toString(),to.toString())))
                count++
                require(count<=5000 && csv.length<=2_000_000){"Choose a shorter period to fit MODE Handyman's import limits."}
            }
        }
        require(count>0){"No completed paid shifts in this period."}
        return csv.toString()
    }
}
