package com.macleanofduartenterprises.time

import android.app.*
import android.content.*
import android.media.RingtoneManager
import android.net.Uri
import android.os.*
import android.widget.*
import org.json.JSONObject
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale

class AlarmEditor:DialogFragment(){
    companion object{
        const val TAG="alarm-editor"
        const val SYSTEM=271
        const val FILE=272
        const val PATTERN=273
        fun open(a:Main,alarm:Bell?){
            val args=Bundle().apply{
                putInt("id",alarm?.id?:0);putInt("h",alarm?.hour?:LocalTime.now().hour);putInt("m",alarm?.minute?:LocalTime.now().minute)
                putString("label",alarm?.label?:"Alarm");putInt("days",alarm?.days?:0)
                putString("alert",(alarm?.alert?:AlertOptions()).json().toString())
            }
            AlarmEditor().also{it.arguments=args}.show(a.fragmentManager,TAG)
        }
    }
    private val main get()=activity as Main
    private var alarmId=0
    private lateinit var time:LocalTime
    private var draftName="Alarm"
    private lateinit var name:EditText
    private var mask=0
    private var options=AlertOptions()
    private lateinit var controls:LinearLayout
    private var preview:AlertOutput?=null
    private var pendingUri:String?=null
    private var pendingKind=0
    private var working=false
    private var pickerDialog:AlertDialog?=null
    override fun onCreate(s:Bundle?){
        super.onCreate(s)
        val b=s?:arguments
        alarmId=b.getInt("id");time=LocalTime.of(b.getInt("h"),b.getInt("m"));mask=b.getInt("days")
        draftName=b.getString("label","Alarm");options=AlertOptions.read(JSONObject(b.getString("alert","{}")))
        pendingUri=b.getString("pendingUri");pendingKind=b.getInt("pendingKind")
    }
    override fun onSaveInstanceState(b:Bundle){
        super.onSaveInstanceState(b);b.putInt("id",alarmId);b.putInt("h",time.hour);b.putInt("m",time.minute);b.putInt("days",mask)
        b.putString("label",if(::name.isInitialized)name.text.toString() else draftName);b.putString("alert",options.json().toString())
        b.putString("pendingUri",pendingUri);b.putInt("pendingKind",pendingKind)
    }
    override fun onCreateDialog(s:Bundle?):Dialog = with(main){
        val panel=form()
        val use24=use24()
        val format=DateTimeFormatter.ofPattern(if(use24)"HH:mm" else "h:mm a")
        label(panel,"Time",14,muted,true)
        lateinit var timeButton:Button
        timeButton=action(panel,time.format(format)){
            TimePickerDialog(this,{_,hour,minute->
                time=LocalTime.of(hour,minute)
                timeButton.text=time.format(format)
            },time.hour,time.minute,use24).show()
        }
        name=field(panel,"Alarm label",draftName)
        label(panel,"Repeat days",16,ink,true)
        val summary=label(panel,AlarmDays.label(mask),15,muted)
        for(group in DayOfWeek.values().toList().chunked(4)){
            val line=row(panel)
            for(day in group){
                val button=ToggleButton(this)
                val title=day.getDisplayName(java.time.format.TextStyle.SHORT,Locale.getDefault())
                button.textOn=title;button.textOff=title;button.isChecked=AlarmDays.includes(mask,day);button.text=title
                button.contentDescription=day.getDisplayName(java.time.format.TextStyle.FULL,Locale.getDefault())
                button.minWidth=0;button.minimumWidth=0;button.setPadding(0,0,0,0);button.isAllCaps=false
                fun paint(){button.background=bg(if(button.isChecked)primary else secondary,8);button.setTextColor(if(button.isChecked)android.graphics.Color.WHITE else ink)}
                paint()
                line.addView(button,LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(dp(2),dp(3),dp(2),dp(3))})
                button.setOnCheckedChangeListener{_,on->
                    mask=if(on)mask or AlarmDays.bit(day) else mask and AlarmDays.bit(day).inv()
                    paint();summary.text=AlarmDays.label(mask)
                }
            }
        }

        controls=col(panel);renderOptions()
        val scroll=ScrollView(this);scroll.addView(panel)
        AlertDialog.Builder(this).setTitle(if(alarmId==0)"New alarm" else "Edit alarm").setView(scroll)
            .setNegativeButton("Cancel",null).setPositiveButton(if(alarmId==0)"Set alarm" else "Save alarm",null).create()
    }
    override fun onStart(){
        super.onStart()
        main.volumeControlStream=android.media.AudioManager.STREAM_ALARM
        val btn=(dialog as AlertDialog).getButton(-1)
        btn.setOnClickListener{main.attempt{
            main.bells.save(alarmId.takeIf{it!=0},time.hour,time.minute,name.text.toString(),mask,options)
            dismiss();main.draw()
        }}
        btn.isEnabled=!working
        if(pendingUri!=null && !working)importPending()
    }
    override fun onStop(){preview?.stop();pickerDialog?.dismiss();pickerDialog=null;super.onStop()}
    override fun onDismiss(d:DialogInterface){preview?.stop();super.onDismiss(d)}
    private fun list(title:String,items:List<String>,pick:(Int)->Unit){
        pickerDialog=AlertDialog.Builder(main).setTitle(title).setItems(items.toTypedArray()){_,ix->main.attempt{pick(ix)}}
            .setNegativeButton("Cancel",null).show()
    }
    private fun renderOptions():Unit=with(main){
        controls.removeAllViews()
        label(controls,"Alarm alert",16,ink,true)
        action(controls,options.mode.title){
            list("Alert mode",AlertMode.values().map{it.title}){i->
                preview?.stop();options=options.copy(mode=AlertMode.values()[i]);renderOptions()
            }
        }
        if(options.mode!=AlertMode.VIBRATE)action(controls,"Ringtone · "+options.toneName){
            val imported=AlarmMedia.imported(this).toList().sortedBy{it.second}
            val choices=listOf("Time chime","Android installed tones","Import audio file…")+imported.map{it.second}
            list("Select ringtone",choices){i->
                preview?.stop()
                when(i){
                    0->{options=options.copy(tone="",toneName="Time chime");renderOptions()}
                    1->{
                        val intent=Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE,RingtoneManager.TYPE_ALL)
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT,true)
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI,RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT,false)
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE,"Choose alarm sound")
                        if(options.tone.startsWith("content:"))intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,Uri.parse(options.tone))
                        try{this@AlarmEditor.startActivityForResult(intent,SYSTEM)}
                        catch(_:ActivityNotFoundException){listInstalledTones()}
                    }
                    2->pickDocument(FILE)
                    else->{val (key,title)=imported[i-3];options=options.copy(tone="import:"+key,toneName=title);renderOptions()}
                }
            }
        }
        if(options.mode!=AlertMode.SOUND)action(controls,"Vibration · "+options.patternName){
            val presets=mutableListOf("pulse" to "Steady pulse","double" to "Double pulse","long" to "Long pulse")
            if(Build.VERSION.SDK_INT>=29){presets+= "click" to "Android click";presets+= "heavy" to "Android heavy click"}
            list("Select vibration",presets.map{it.second}+"Import pattern file…"){i->
                preview?.stop()
                if(i==presets.size){
                    AlertDialog.Builder(this).setTitle("Import vibration pattern")
                        .setMessage("Choose a text or CSV file containing alternating pause and vibration durations in milliseconds. For example, 0,300,200,600 plays a short pulse followed by a longer one.")
                        .setNegativeButton("Cancel",null).setPositiveButton("Choose file"){_,_->this@AlarmEditor.main.attempt{pickDocument(PATTERN)}}.show()
                }else{val (key,title)=presets[i];options=options.copy(pattern=key,patternName=title);renderOptions()}
            }
        }
        if(options.mode!=AlertMode.VIBRATE && getSystemService(android.media.AudioManager::class.java).getStreamVolume(android.media.AudioManager.STREAM_ALARM)==0)
            label(controls,"Alarm volume is muted. Use the volume buttons to hear the preview.",15,muted)
        if(working)label(controls,"Importing file…",15,muted)
        else action(controls,"Preview alert"){
            if(preview==null)preview=AlertOutput(applicationContext)
            preview!!.start(options,true)
        }
    }
    private fun listInstalledTones(){
        val manager=RingtoneManager(main)
        manager.setType(RingtoneManager.TYPE_ALL)
        val sounds=manager.cursor.use{cursor->
            buildList{
                while(cursor.moveToNext())add(cursor.getString(RingtoneManager.TITLE_COLUMN_INDEX) to manager.getRingtoneUri(cursor.position))
            }
        }
        require(sounds.isNotEmpty()){"Android has no installed tones. Import an audio file or select Time chime."}
        list("Installed sounds",sounds.map{it.first}){i->
            options=options.copy(tone=sounds[i].second.toString(),toneName=sounds[i].first);renderOptions()
        }
    }
    private fun pickDocument(kind:Int){
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType(if(kind==FILE)"audio/*" else "*/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION),kind)
    }
    override fun onActivityResult(request:Int,result:Int,data:Intent?){
        super.onActivityResult(request,result,data)
        if(result!=Activity.RESULT_OK || data==null)return
        if(request==SYSTEM){
            val uri=data.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)?:return
            if(uri.scheme!="content")return
            val title=runCatching{RingtoneManager.getRingtone(main,uri)?.getTitle(main)}.getOrNull()?:"Android alarm tone"
            options=options.copy(tone=uri.toString(),toneName=title);renderOptions()
        }else if(request==FILE || request==PATTERN){
            val uri=data.data?:return
            if(uri.scheme!="content")return
            runCatching{main.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}
            pendingUri=uri.toString();pendingKind=request;importPending()
        }
    }
    private fun importPending(){
        val uri=Uri.parse(pendingUri?:return)
        val kind=pendingKind
        val app=main.applicationContext
        working=true;renderOptions()
        (dialog as? AlertDialog)?.getButton(-1)?.isEnabled=false
        Thread{
            val result=runCatching{if(kind==FILE)AlarmMedia.importAudio(app,uri)else AlarmMedia.importPattern(app,uri)}
            Handler(Looper.getMainLooper()).post{
                if(!isAdded || activity==null || activity.isDestroyed)return@post
                working=false;pendingUri=null
                runCatching{app.contentResolver.releasePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}
                result.onSuccess{(key,title)->options=if(kind==FILE)options.copy(tone=key,toneName=title) else options.copy(pattern=key,patternName=title)}
                    .onFailure{main.note("Import failed. "+(it.localizedMessage?:"Choose another file."))}
                renderOptions();(dialog as? AlertDialog)?.getButton(-1)?.isEnabled=true
            }
        }.start()
    }
}
