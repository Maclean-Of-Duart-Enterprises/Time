import com.macleanofduartenterprises.time.*
import java.io.File

fun main(args:Array<String>){
    val bytes=File(args.single()).readBytes()
    val setup=SetupCodec.read(bytes)
    val incoming=setup.workers.single().profile
    val old=Person(10," "+incoming.name.uppercase().replace(" ","   ")+" ",fields=mapOf("Outdated" to "x"))
    val duplicate=incoming.copy(id=20)
    val otherBusiness=incoming.copy(id=30,business="900000000")
    check(setupMatches(incoming,listOf(old,duplicate,otherBusiness))==listOf(old,duplicate))
    check(setupMatches(incoming,listOf(old))==listOf(old))
    check(setupMatches(incoming,listOf(duplicate))==listOf(duplicate))
    check(setupMatches(incoming.copy(name="Updated name"),listOf(duplicate))==listOf(duplicate))
    val differentId=duplicate.copy(employee="900000000")
    check(setupMatches(incoming,listOf(differentId))==listOf(differentId))
    check(setupMatches(incoming,listOf(differentId,duplicate))==listOf(duplicate))
    check(setupMatches(incoming,listOf(otherBusiness)).isEmpty())
    val pin="012345"
    val authorized=SetupCodec.read(SetupCodec.withPassword(bytes,pin))
    check(authorized.password==pin && authorized.workers==setup.workers && authorized.jobs==setup.jobs)
    check(runCatching{SetupCodec.withPassword(bytes,"bad")}.isFailure)
    println("Passed employee matching, legacy duplicates, business isolation and PIN preparation for the input setup.")
}
