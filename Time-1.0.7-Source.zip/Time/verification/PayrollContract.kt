import com.macleanofduartenterprises.time.*
import com.macleanofduartenterprises.modehandyman.core.*
import com.example.util.simpletimetracker.domain.record.model.*
import java.time.*
import java.io.File

fun main(args:Array<String>){
    val z=ZoneId.of("America/New_York")
    val worker=Person(1,"Иван, Jr.","7","2",mapOf("Crew" to "East, field\ncrew"))
    check(Csv.parse(Csv.profiles(listOf(worker))).single()==worker.copy(id=0))
    check(Csv.parse("\uFEFFemployee_name;Team\r\nAnna;One").single().fields["Team"]=="One")
    check(runCatching{Csv.parse("name,employee_name\nA,B")}.isFailure)
    fun instant(t:String)=ZonedDateTime.of(LocalDateTime.parse(t),z).toInstant().toEpochMilli()
    fun shift(a:String,b:String,breaks:List<Range> = emptyList())=Shift(Record(1,1,instant(a),instant(b),"Job: A3 · Remodel\nInstall, \"north wall\"",emptyList()),z,breaks,"1.5")
    fun checkShift(s:Shift,seconds:Long,rows:Int){
        val first=Instant.ofEpochMilli(s.record.timeStarted).atZone(z).toLocalDate()
        val last=Instant.ofEpochMilli(s.record.timeEnded).atZone(z).toLocalDate()
        val csv=Cards.export(worker,listOf(s),first,last)
        val p=PayrollCsv.parse(csv)
        check(p.employeeId=="7" && p.employeeName==worker.name && p.profileId=="2")
        check(p.entries.size==rows && p.entries.sumOf{it.workedSeconds()}==seconds)
        check(p.entries.all{it.notes==s.record.comment && it.multiplier=="1.5"})
        println("Passed "+first+" paid="+seconds+" rows="+rows)
    }
    checkShift(shift("2026-11-16T08:00","2026-11-16T16:30",listOf(Range(instant("2026-11-16T12:00"),instant("2026-11-16T12:30")))),28800,1)
    checkShift(shift("2026-11-16T22:00","2026-11-17T06:00"),28800,1)
    checkShift(shift("2026-03-08T00:00","2026-03-08T04:00"),10800,1)
    checkShift(shift("2026-11-01T00:00","2026-11-01T04:00"),18000,1)
    checkShift(shift("2026-11-16T00:00","2026-11-17T00:00"),86400,1)
    checkShift(shift("2026-11-16T21:00","2026-11-18T02:30",listOf(Range(instant("2026-11-16T23:59"),instant("2026-11-17T00:01")))),29*3600+30*60-120,3)
    if(args.isNotEmpty()){
        val p=PayrollCsv.parse(File(args[0]).readText())
        check(p.entries.single().workedSeconds()>0 && p.entries.single().notes.contains("Site visit"))
        println("Actual Android timecard accepted: "+p.entries.single().notes)
    }
}
