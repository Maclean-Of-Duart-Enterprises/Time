import com.macleanofduartenterprises.time.AlarmDays
import java.time.*

fun main() {
    val zone = ZoneId.of("America/New_York")
    val monday = LocalDate.of(2026,11,16)
    for(mask in 0..127) for(day in 0L..6L) for(minute in listOf(59,60,61)) {
        val now = monday.plusDays(day).atStartOfDay(zone).plusMinutes(minute.toLong())
        val next = Instant.ofEpochMilli(AlarmDays.next(1,0,mask,now)).atZone(zone)
        check(next > now && next.hour == 1 && next.minute == 0)
        check(mask == 0 || AlarmDays.includes(mask,next.dayOfWeek))
        var candidate = now.toLocalDate().atTime(1,0).atZone(zone)
        while(candidate < next) {
            check(candidate <= now || mask != 0 && !AlarmDays.includes(mask,candidate.dayOfWeek))
            candidate=candidate.plusDays(1)
        }
    }
    val sunday=AlarmDays.bit(DayOfWeek.SUNDAY)
    val spring=ZonedDateTime.of(2026,3,7,18,0,0,0,zone)
    check(Instant.ofEpochMilli(AlarmDays.next(2,30,sunday,spring)).atZone(zone).toLocalTime()==LocalTime.of(3,30))
    val fall=ZonedDateTime.of(2026,11,1,1,30,0,0,zone).withEarlierOffsetAtOverlap()
    check(Instant.ofEpochMilli(AlarmDays.next(1,30,sunday,fall)).atZone(zone).toLocalDate()==fall.toLocalDate().plusWeeks(1))
    println("Passed all 128 day selections across a week and both DST transitions.")
}
