package checks

import android.app.*
import android.content.*
import android.os.*
import android.view.*
import android.widget.*
import com.macleanofduartenterprises.time.*
import java.time.*
import java.io.File

class DeviceChecks:Instrumentation(){
    override fun onCreate(args:Bundle?){super.onCreate(args);start()}
    private lateinit var a:Main
    private val log=mutableListOf<String>()
    private fun descendants(v:View):List<View> = listOf(v)+if(v is ViewGroup)(0 until v.childCount).flatMap{descendants(v.getChildAt(it))} else emptyList()
    private fun ui(block:()->Unit){var issue:Throwable?=null;runOnMainSync{try{block()}catch(t:Throwable){issue=t}};issue?.let{throw it};waitForIdleSync()}
    private fun labels()=descendants(a.shell).filterIsInstance<TextView>().map{it.text.toString()}
    private fun tap(text:String){val v=descendants(a.shell).filterIsInstance<Button>().firstOrNull{it.text.toString()==text}?:error("Missing "+text+" on "+labels());v.performClick()}
    private fun edits()=descendants(a.dialog!!.window!!.decorView).filterIsInstance<EditText>()
    private fun ok(){a.dialog!!.getButton(-1).performClick()}
    private fun blocked(block:()->Unit){check(runCatching(block).isFailure){"Mutation permitted while locked"}}
    override fun onStart(){
        val result=Bundle()
        try{
            val i=Intent(targetContext,Main::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            a=startActivitySync(i) as Main
            check(a.db.people().isEmpty() && a.db.jobs().isEmpty() && !a.guard.locked){"Tests require fresh disposable app data."}
            ui{
                tap("Profiles");tap("Add worker")};ui{edits()[0].setText("Test worker");edits()[1].setText("7");edits()[2].setText("2");ok()
                check(a.db.people().single().name=="Test worker")
                tap("Jobs");tap("Add job")};ui{edits()[0].setText("Site visit");edits()[1].setText("JOB-4");edits()[2].setText("1.5");ok()
                check(a.db.jobs().single().factor=="1.5")
            }
            val person=a.db.people().single();val job=a.db.jobs().single()
            val imported=Csv.parse("employee_name,employee_id,business_profile_id,Truck\nTest worker,7,2,Blue")
            val jobs=JobCsv.parse("job_name,job_code,Project lead\nSite visit,JOB-4,Anna")
            a.db.importAll(imported);a.db.importJobs(jobs)
            check(a.db.people().single().fields["Truck"]=="Blue" && a.db.jobs().single().fields["Project lead"]=="Anna" && a.db.jobs().single().factor=="1.5")
            val mixed=JobCsv.parse("job_name,job_code\nOther,A3\nDuplicate,A3")
            blocked{a.db.importJobs(mixed)};check(a.db.jobs().size==1)
            log+="Worker/job manual creation, custom CSV fields, matching and rollback"
            ui{
                descendants(a.shell).first{it.contentDescription=="Settings"}.performClick();tap("Admin panel");descendants(a.shell).filterIsInstance<Switch>().single().performClick()};ui{
                edits().forEach{it.setText("123456")};ok();check(a.guard.locked && !a.guard.unlocked)
                tap("Profiles");check("Add job" !in labels() && "Edit job" !in labels() && "Archive job" !in labels() && "Import job CSV" !in labels())
                tap("Workers");check("Edit profile" !in labels() && "Import CSV" !in labels())
                descendants(a.shell).first{it.contentDescription=="Settings"}.performClick();tap("Admin panel");tap("Unlock admin panel")};ui{edits().single().setText("909090");ok();check(!a.guard.unlocked)
                a.dialog!!.dismiss()
            }
            blocked{a.db.saveJob(job.copy(archived=true))};blocked{a.db.edit(person.copy(name="Changed"))}
            blocked{a.db.importAll(imported)};blocked{a.db.importJobs(jobs)};blocked{a.guard.disable()}
            log+="Profile UI, storage writes, wrong PIN and imports blocked under lock"
            ui{
                tap("Timecard");tap("Job · Unassigned")};ui{a.dialog!!.listView.performItemClick(a.dialog!!.listView.getChildAt(1),1,1)
                };ui{tap("Clock in")};ui{edits().single().setText("Inspect panel");ok();check(a.db.live(person.id)!=null)
            }
            Thread.sleep(1600)
            ui{tap("Start break")};Thread.sleep(1300);ui{tap("End break")};Thread.sleep(1100)
            ui{tap("Clock out");check(a.db.live(person.id)==null)}
            val shift=a.db.shifts(person.id).single();check(shift.factor=="1.5" && shift.breaks.single().duration>=1000 && shift.record.comment.contains("JOB-4"))
            val csv=Cards.export(person,listOf(shift),a.from,a.to)
            result.putString("csv64",android.util.Base64.encodeToString(csv.toByteArray(),2))
            log+="Locked job selection, shift, unpaid break, clock-out and CSV"
            ui{
                tap("Clock");tap("World clock");check("Add time zone" in labels());tap("Alarms");check("Add alarm" in labels())
                tap("Timer");check("Start timer" in labels());tap("Local clock")
            }
            val bells=a.bells
            val soon=LocalTime.now().plusMinutes(2);bells.save(null,soon.hour,soon.minute,"Work alarm",0)
            check(targetContext.getSystemService(AlarmManager::class.java).nextAlarmClock!=null)
            bells.remove(bells.alarms().single().id)
            bells.time(65000);bells.pause();check(!bells.timerRunning && bells.timerRemaining>0);bells.time(bells.timerRemaining);bells.reset()
            bells.time(2400)
            val pref=a.getSharedPreferences("ring",0)
            for(i2 in 1..80){if(pref.getString("label","")=="Timer finished")break;Thread.sleep(250)}
            check(pref.getString("label","")=="Timer finished"){"Timer did not deliver the alert"}
            a.stopService(Intent(a,Ring::class.java))
            log+="Unlocked public clock tools, AlarmManager schedule, pause/resume and timer alert delivery"
            ui{
                descendants(a.shell).first{it.contentDescription=="Settings"}.performClick();tap("Admin panel");tap("Unlock admin panel")};ui{edits().single().setText("123456");ok();check(a.guard.unlocked)
                tap("Jobs");tap("Archive job")};ui{ok()};ui{check(a.db.jobs().single().archived);tap("Restore job")
                tap("Clock");check(!a.guard.unlocked)
                descendants(a.shell).first{it.contentDescription=="Settings"}.performClick();tap("Admin panel");tap("Unlock admin panel")};ui{edits().single().setText("123456");ok()
                descendants(a.shell).filterIsInstance<Switch>().single().performClick()};ui{ok()} ;ui{
                check(!a.guard.locked);tap("Profiles");check("Edit job" in labels())
            }
            log+="Admin archive, restore, automatic re-lock and controls off"
            result.putString("checks",log.joinToString(" | "));finish(Activity.RESULT_OK,result)
        }catch(t:Throwable){result.putString("failedAfter",log.toString());result.putString("failure",android.util.Log.getStackTraceString(t));finish(Activity.RESULT_CANCELED,result)}
    }
}
