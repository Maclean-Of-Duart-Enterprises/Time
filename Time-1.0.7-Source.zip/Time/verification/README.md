# Verification cases

DeviceChecks.kt is a separate Android Instrumentation harness for a disposable emulator with fresh Time app data. It drives the profile, PIN, job, timecard and clock screens and exercises storage guards. It verifies that a countdown actually delivers the ringing service. Its result includes a Base64-encoded CSV from the recorded shift. The harness is outside the application source set.

PayrollContract.kt is a host-side Kotlin check. Compile it with Time's tracking core and the unmodified Payroll.kt, PayrollCsv.kt and MoneyMath.kt from the MODE Handyman 2.2.0 reference project. It exercises normal shifts, overnight shifts, breaks, both daylight-saving transitions, 24-hour and multi-day work, quoted notes and worker identity. Pass the CSV saved by the device check as its optional argument to validate the Android-generated contents.

AlarmDaysCheck.kt exercises every combination of repeat days before, at and after the alarm time, plus both US daylight-saving transitions. UpdateChecks.kt drives alarm selection and editing, opening the timecard editor, adding and adjusting an unpaid break, PIN protection and CSV export. On a disposable emulator, run the instrumentation with phase=seed on 1.0.0, install the 1.0.1 release as an update, and run the instrumentation again without that argument.

AlertChecks.kt is the 1.0.1 to 1.0.2 upgrade check. Its test-only document provider serves a known WAV and vibration pattern. The check covers editing alert modes, choosing a system tone, importing both files, retaining repeat and alert settings, requesting audio playback and vibration, falling back to the bundled sound and posting the ringing notification. Run the alert check with phase=schedule after the upgrade check to schedule a real alarm using the imported sound.

SetupChecks.kt runs on the host JVM with the release classes and an org.json runtime. Pass examples/Time-employee-setup-example.json as the argument. It checks the employee package, signed and altered files, MODE worker mapping, job address CSV round-trips, invalid settings, day/night selection and 12/24-hour display.
