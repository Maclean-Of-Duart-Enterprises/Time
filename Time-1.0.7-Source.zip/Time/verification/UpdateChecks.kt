package checks

import android.app.*
import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.*
import com.example.util.simpletimetracker.domain.record.model.Range
import com.macleanofduartenterprises.time.*
import com.macleanofduartenterprises.time.Person
import java.time.*

/** Run with phase=seed on 1.0.0, then install 1.0.1 over it and rerun on a disposable emulator. */
class UpdateChecks:Instrumentation(){
    lateinit var a:Main
    private var seed=false
    override fun onCreate(arguments:Bundle?){super.onCreate(arguments);seed=arguments?.getString("phase")=="seed";start()}
    private fun views(v:View):List<View> = listOf(v)+if(v is ViewGroup)(0 until v.childCount).flatMap{views(v.getChildAt(it))} else emptyList()
    private fun ui(fn:()->Unit){var fail:Throwable?=null;runOnMainSync{try{fn()}catch(t:Throwable){fail=t}};fail?.let{throw it};waitForIdleSync()}
    private fun tap(name:String){views(a.shell).filterIsInstance<Button>().first{it.text.toString()==name}.performClick()}
    private fun shown()=(a.fragmentManager.findFragmentByTag(AlarmEditor.TAG) as? AlarmEditor)?.dialog as? AlertDialog ?: a.dialog!!
    private fun form()=views(shown().window!!.decorView)
    private fun ok(){shown().getButton(-1).performClick()}
    private fun edits()=form().filterIsInstance<EditText>()
    private fun weekday(day:String)=form().filterIsInstance<ToggleButton>().first{it.contentDescription==day}
    private val workerName="Schedule update checks"
    override fun onStart(){
        val result=Bundle()
        try{
            a=startActivitySync(Intent(targetContext,Main::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) as Main
            if(seed){
                check(!a.guard.locked && a.db.people().none{it.name==workerName})
                val id=a.db.edit(Person(name=workerName))
                a.db.start(id,"Original 1.0.0 shift","1");Thread.sleep(1600);a.db.punch(id,true)
                val add=a.bells.javaClass.getMethod("add",Int::class.javaPrimitiveType,Int::class.javaPrimitiveType,String::class.java,Boolean::class.javaPrimitiveType)
                add.invoke(a.bells,6,10,"Legacy once",false);add.invoke(a.bells,6,11,"Legacy daily",true)
            }else{
                val worker=a.db.people().single{it.name==workerName}
                val original=a.db.shifts(worker.id).single{it.record.comment=="Original 1.0.0 shift"}
                val once=a.bells.alarms().single{it.label=="Legacy once"}
                val daily=a.bells.alarms().single{it.label=="Legacy daily"}
                check(once.enabled && daily.enabled && once.days==0 && daily.days==127)
                ui{tap("Alarms");tap("Add alarm")}
                ui{weekday("Monday").performClick();weekday("Thursday").performClick();edits().single().setText("Job alarm");ok()}
                val alarm=a.bells.alarms().single{it.label=="Job alarm"}
                check(alarm.enabled && alarm.days==9)
                fun alarmSwitch()=views(a.sheet).filterIsInstance<Switch>().single{it.contentDescription.toString().startsWith("Enable alarm Job alarm at ")}
                ui{alarmSwitch().performClick()}
                check(!a.bells.alarms().single{it.id==alarm.id}.enabled)
                check(a.bells.consume(alarm.id,alarm.due)==null)
                a.bells.restore(Intent.ACTION_TIMEZONE_CHANGED)
                ui{check(!alarmSwitch().isChecked);alarmSwitch().performClick()}
                check(a.bells.alarms().single{it.id==alarm.id}.enabled)
                ui{
                    val title=views(a.sheet).filterIsInstance<TextView>().single{it.text.toString().endsWith("·  Job alarm")}
                    (title.parent.parent as View).performClick()
                }
                ui{
                    check(weekday("Monday").isChecked && weekday("Thursday").isChecked)
                    weekday("Monday").performClick();weekday("Saturday").performClick()
                    edits().single().setText("Edited alarm");ok()
                }
                val updated=a.bells.alarms().single{it.id==alarm.id}
                check(updated.label=="Edited alarm" && updated.days==40 && a.bells.alarms().none{it.label=="Job alarm"})
                a.bells.restore(Intent.ACTION_TIMEZONE_CHANGED)
                val current=a.bells.alarms().single{it.id==alarm.id}
                check(a.bells.consume(current.id,current.due)?.label=="Edited alarm")
                val next=a.bells.alarms().single{it.id==alarm.id}
                check(next.due>current.due && AlarmDays.includes(40,Instant.ofEpochMilli(next.due).atZone(ZoneId.systemDefault()).dayOfWeek))
                check(a.bells.consume(current.id,current.due)==null)
                ui{a.pick(worker);tap("Timecard");tap("Add manual shift")}
                val day=LocalDate.now().minusDays(1)
                ui{
                    edits()[0].setText(day.toString()+" 08:00")
                    edits()[1].setText(day.toString()+" 17:00")
                    form().filterIsInstance<Button>().single{it.text=="Add unpaid break"}.performClick()
                    edits()[2].setText(day.toString()+" 12:00");edits()[3].setText(day.toString()+" 12:30")
                    edits().last().setText("Site visit");ok()
                }
                val shift=a.db.shifts(worker.id).single{it.record.comment=="Site visit"}
                check(shift.record.duration-shift.breaks.single().duration==30600000L)
                ui{
                    val note=views(a.sheet).filterIsInstance<TextView>().single{it.text=="Site visit"}
                    views(note.parent as View).filterIsInstance<Button>().single{it.text=="Edit shift"}.performClick()
                }
                ui{edits()[1].setText(day.toString()+" 16:30");ok()}
                val corrected=a.db.shifts(worker.id).single{it.record.id==shift.record.id}
                check(corrected.record.duration-corrected.breaks.single().duration==28800000L)
                check(a.db.shifts(worker.id).contains(original))
                val r=corrected.record
                check(runCatching{a.db.saveShift(worker.id,null,r.timeStarted,r.timeEnded,corrected.zone,emptyList(),"Overlap",null)}.isFailure)
                check(runCatching{a.db.saveShift(worker.id,corrected,r.timeStarted,r.timeEnded,corrected.zone,listOf(Range(r.timeStarted-1000,r.timeEnded)),"Broken",null)}.isFailure)
                check(a.db.shifts(worker.id).contains(corrected))
                ui{a.guard.enable("142536");tap("Add manual shift")}
                check(runCatching{a.db.saveShift(worker.id,corrected,r.timeStarted,r.timeEnded,corrected.zone,emptyList(),"Locked",null)}.isFailure)
                ui{edits().single().setText("142536");ok()}
                check(a.guard.unlocked)
                ui{a.dialog!!.cancel()};check(!a.guard.unlocked)
                a.guard.unlock("142536");a.guard.disable()
                result.putString("csv64",android.util.Base64.encodeToString(Cards.export(worker,listOf(corrected),day,day).toByteArray(),2))
            }
            result.putString("phase",if(seed)"1.0.0 alarms and shift seeded" else "upgrade, weekday selection, edit, reschedule, manual and edited shifts, breaks, validation, PIN, export passed")
            finish(Activity.RESULT_OK,result)
        }catch(t:Throwable){result.putString("failure",android.util.Log.getStackTraceString(t));finish(Activity.RESULT_CANCELED,result)}
    }
}
