package checks

import android.app.*
import android.content.*
import android.database.MatrixCursor
import android.media.RingtoneManager
import android.net.Uri
import android.os.*
import android.provider.OpenableColumns
import android.view.*
import android.widget.*
import com.macleanofduartenterprises.time.*
import java.io.File

/** Test-only provider with two fixed, synthetic documents. */
class ToneDocuments:ContentProvider(){
    override fun onCreate()=true
    override fun getType(uri:Uri)=if(uri.lastPathSegment=="sound.wav")"audio/wav" else "text/plain"
    override fun query(uri:Uri,p:Array<String>?,s:String?,a:Array<String>?,o:String?)=
        MatrixCursor(arrayOf(OpenableColumns.DISPLAY_NAME)).apply{addRow(arrayOf(uri.lastPathSegment))}
    override fun openFile(uri:Uri,mode:String):ParcelFileDescriptor{
        val c=context!!
        val file=File(c.cacheDir,if(uri.lastPathSegment=="sound.wav")"sound.wav" else "pattern.csv")
        if(file.name=="sound.wav"){
            val target=c.createPackageContext("com.macleanofduartenterprises.time",0)
            target.resources.openRawResource(target.resources.getIdentifier("time_chime","raw",target.packageName)).use{i->file.outputStream().use{i.copyTo(it)}}
        }else file.writeText("0,250,200,450")
        return ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY)
    }
    override fun insert(u:Uri,v:ContentValues?):Uri?=null
    override fun update(u:Uri,v:ContentValues?,s:String?,a:Array<String>?)=0
    override fun delete(u:Uri,s:String?,a:Array<String>?)=0
}

class AlertChecks:Instrumentation(){
    private lateinit var a:Main
    private var phase=""
    private val stages=mutableListOf<String>()
    override fun onCreate(b:Bundle?){super.onCreate(b);phase=b?.getString("phase").orEmpty();start()}
    private fun ui(f:()->Unit){var issue:Throwable?=null;runOnMainSync{try{f()}catch(t:Throwable){issue=t}};issue?.let{throw it};waitForIdleSync()}
    private fun walk(v:View):List<View> = listOf(v)+if(v is ViewGroup)(0 until v.childCount).flatMap{walk(v.getChildAt(it))}else emptyList()
    private fun tap(v:View,text:String){walk(v).filterIsInstance<Button>().first{it.text.startsWith(text)}.performClick()}
    private fun editor()=a.fragmentManager.findFragmentByTag(AlarmEditor.TAG) as AlarmEditor
    private fun form()=editor().dialog.window!!.decorView
    private fun choose(index:Int){
        val field=AlarmEditor::class.java.getDeclaredField("pickerDialog").apply{isAccessible=true}
        val list=(field.get(editor()) as AlertDialog).listView
        list.performItemClick(list.getChildAt(index-list.firstVisiblePosition),index,index.toLong())
    }
    override fun onStart(){
        val result=Bundle()
        try{
            a=startActivitySync(Intent(targetContext,Main::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) as Main
            if(phase=="schedule"){
                val tone=a.bells.alarms().first{it.alert.tone.startsWith("import:")}.alert
                val next=java.time.LocalTime.now().plusMinutes(1)
                a.bells.save(null,next.hour,next.minute,"Background ring check",0,tone.copy(mode=AlertMode.SOUND))
                stages+="scheduled a real alarm with imported audio"
            }else if(phase=="seed"){
                val save=a.bells.javaClass.getMethod("save",Integer::class.java,Int::class.javaPrimitiveType,Int::class.javaPrimitiveType,String::class.java,Int::class.javaPrimitiveType)
                save.invoke(a.bells,null,6,37,"Carry over",17)
                stages+="saved original 1.0.1 alarm"
            }else{
                val old=a.bells.alarms().single{it.label=="Carry over"}
                check(old.days==17 && old.alert==AlertOptions())
                stages+="existing alarm retained its repeat days and acquired sound plus vibration"
                ui{tap(a.shell,"Alarms");tap(a.shell,"Add alarm")}
                ui{
                    walk(form()).filterIsInstance<EditText>().single().setText("Imported alert")
                    walk(form()).filterIsInstance<ToggleButton>().first().performClick()
                    tap(form(),"Sound and vibration")
                }
                ui{choose(1)}
                check(walk(form()).filterIsInstance<Button>().any{it.text=="Sound only"})
                ui{tap(form(),"Sound only")};ui{choose(0)}
                // Drive the same activity results returned by Android's system and document pickers.
                val uri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ui{editor().onActivityResult(AlarmEditor.SYSTEM,Activity.RESULT_OK,Intent().putExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI,uri))}
                check(walk(form()).filterIsInstance<Button>().none{it.text=="Ringtone · Time chime"})
                fun pickFile(request:Int,file:String,prefix:String){
                    ui{editor().onActivityResult(request,Activity.RESULT_OK,Intent().setData(Uri.parse("content://time.alert.test/"+file)))}
                    for(i in 1..80){
                        var found=false
                        ui{found=walk(form()).filterIsInstance<Button>().any{it.text.toString()==prefix+file}}
                        if(found)return
                        Thread.sleep(150)
                    }
                    error("Import timed out: "+file)
                }
                pickFile(AlarmEditor.FILE,"sound.wav","Ringtone · ")
                pickFile(AlarmEditor.PATTERN,"pattern.csv","Vibration · ")
                ui{tap(form(),"Preview alert");(editor().dialog as AlertDialog).getButton(-1).performClick()}
                val bell=Bells(a).alarms().single{it.label=="Imported alert"}
                check(bell.days==1 && bell.alert.tone.startsWith("import:") && bell.alert.pattern=="0,250,200,450")
                check(AlarmMedia.imported(a).values.contains("sound.wav"))
                stages+="system tone selection, audio file import, vibration pattern import, preview and persistence"
                val output=AlertOutput(a)
                for(mode in AlertMode.values()){
                    ui{
                        output.start(bell.alert.copy(mode=mode))
                        check(output.playing==(mode!=AlertMode.VIBRATE))
                        check(output.hasVibration==(mode!=AlertMode.SOUND && a.getSystemService(Vibrator::class.java).hasVibrator()))
                        output.stop()
                    }
                }
                ui{output.start(AlertOptions(tone="import:"+"0".repeat(64)));check(output.playing);output.stop()}
                stages+="three modes and missing-tone fallback exercised with Android MediaPlayer"
                val event=a.bells.consume(bell.id,bell.due)!!
                check(event.alert==bell.alert && a.bells.alarms().single{it.id==bell.id}.alert==bell.alert)
                a.startForegroundService(Intent(a,Ring::class.java).putExtra("label",event.label).putExtra("alert",event.alert.json().toString()))
                val nm=a.getSystemService(NotificationManager::class.java)
                for(i in 1..100){if(nm.activeNotifications.any{it.id==703})break;Thread.sleep(100)}
                check(nm.activeNotifications.any{it.id==703 && it.notification.channelId==AlarmMedia.CHANNEL})
                a.stopService(Intent(a,Ring::class.java))
                stages+="repeat delivery and foreground alarm notification"
            }
            result.putString("checks",stages.joinToString(" | "));finish(Activity.RESULT_OK,result)
        }catch(t:Throwable){result.putString("stages",stages.joinToString());result.putString("failure",android.util.Log.getStackTraceString(t));finish(Activity.RESULT_CANCELED,result)}
    }
}
