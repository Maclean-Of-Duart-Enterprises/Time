# Time 1.0.6

A local Android clock and employee timecard app from Maclean Of Duart Enterprises. Package `com.macleanofduartenterprises.time`. Requires Android 8.0 or later. Clock and timecard features work offline. Choosing OsmAnd navigation for a street address uses an online OpenStreetMap lookup. No account or broad storage permission is required.

## Setup

1. Open **Profiles → Workers** to add workers manually or import a CSV. Use the same worker name as MODE Handyman. Supply MODE's numeric employee ID and business profile ID if known. Both ID fields can be blank.
2. Under **Profiles → Jobs**, add a job name and optional job code. Set a pay multiplier if appropriate. Enter a job site address to navigate with OsmAnd, Google Maps, OpenStreetMap or another map app. Add custom fields such as client or project lead to any job or worker. See **examples** for editable CSV templates.
3. Open **Settings → Admin panel**, switch on **Admin controls**, then set and confirm a 6–12 digit PIN. Record the PIN before closing the panel. After enabling the switch, ordinary users can view profiles and choose a worker and active job. Worker and job creation, changes and CSV imports, plus job archiving and restoration, require the PIN in the Admin panel. Job multipliers are also protected while the switch is on. Returning from a file picker asks for the PIN again when required. Leaving Admin or sending the app to the background locks the panel.
4. To make profiles freely editable again, unlock **Admin**, turn the switch off and confirm. This is a local app lock. Clearing Android app storage or uninstalling removes the records and PIN.

**Delete employee** and **Delete job** are available in Profiles when controls are off or inside the unlocked Admin panel. Deleting an employee permanently removes their shifts, breaks and attached files after confirmation. Deleting a job preserves the recorded hours, job notes and pay multiplier on existing timecards. To combine a manual employee and a MODE duplicate with their timecards intact, reimport the employee setup JSON.

## Record a shift

Go to **Timecard**, select the worker and an active job, then **Clock in**. An unassigned shift is also supported. Add optional shift notes. **Start break** pauses paid time, **End break** resumes it, and **Clock out** completes the shift. Running shifts and breaks persist across app restarts. Each worker can have one open shift. The job name, code and applicable pay multiplier are captured at clock-in. Editing or archiving a job later leaves those completed shift details intact.

Use **Add manual shift** for missed punches, or **Edit shift** on a completed entry to correct its dates, clock times, unpaid breaks or notes. Enter an overnight shift using the following day for clock-out. When admin controls are on, a correction requires the admin PIN. A saved correction updates the pay-period totals and the next CSV export.

Use **Delete shift** to remove one whole completed shift and its breaks. **Delete timecard** removes the selected worker’s completed time within the displayed pay period, including all pages. The confirmation shows the worker, dates and paid total. The app keeps active shifts, other workers’ time and payroll rows outside the period. These actions require the admin PIN when controls are enabled. Previously exported CSV files are independent copies.

Select **From** and **Through** on the timecard. Totals cover completed paid time in that inclusive period. Tap **Export timecard CSV** to choose where to save. In MODE Handyman 2.2.0, open **People and materials → Employee and Subcontractor**, select the matching person and choose **Import timecard CSV**. MODE creates an editable draft for review.

The UTF-8 CSV contains employee identifiers, work date, start and end times, unpaid break minutes, exact paid seconds, multiplier, notes and pay-period dates. Job name and code appear in the notes. Other custom profile details are available in the separate profile CSV. Ordinary overnight shifts use their start date. Shifts exceeding 24 hours are split. For clock changes involving daylight saving time and full 24-hour segments, duration-only rows preserve the actual paid seconds.

## Profile CSVs

Worker files use an `employee_name` column with optional `employee_id` and `business_profile_id`. Job files use `job_name`, optional `job_code` and optional `multiplier`. Other headings become custom field labels. Commas, semicolons and tabs are supported, with quoted fields for embedded delimiters or newlines. Existing workers match by employee ID within a business, or by name within that business when an ID is omitted. Existing jobs match by code, or by name when the code is omitted. A supplied field replaces that field's value. An omitted custom column retains its previous value. A rejected batch leaves the existing profiles intact. The job CSV export includes active jobs.

## Settings

Use the gear in the upper-right corner for the app theme (automatic, light or dark), local and world clock display (analog, digital or both), 12/24-hour formatting and optional seconds. The Admin panel and employee setup JSON import are also here. See [Employee setup files](EMPLOYEE-SETUP.md) for phone-to-phone authorization, attachments and the MODE integration format.

## Clock tools

Use the switch beside each alarm to turn it off or on. Turning it off keeps its settings. Turning it on schedules the next matching time. One-time alarms switch off after ringing and can be reused.

Tap a saved alarm or **Edit alarm** to change its time, label or repeat days. Leave all days off to ring once, or select any combination from Monday through Sunday.

Each alarm supports **Sound only**, **Vibration only**, or **Sound and vibration**. Tap **Ringtone** to choose Time chime, an Android-installed tone, or an audio file. Imported audio is copied into the app and can be reused after the original file is moved. The built-in Time chime also plays if a system tone becomes unavailable. Use **Vibration** to select a preset or import a text/CSV sequence of alternating pause and vibration lengths in milliseconds, such as `0,300,200,600`. Use **Preview alert** to try the combination before saving. Sound uses Android's alarm volume.

Time creates the alarm notification channel on startup. On Android 13 or later it requests notification permission when first needed. Tap **Allow** to show alarm notifications, or **Enable alarm notifications** for the Android app or channel settings if notifications were disabled.

Open **Clock** for local time, searchable world time zones, one-time alarms or alarms repeating on any selection of weekdays, and a countdown timer with pause, resume and reset. Allow alarm notifications when prompted so the Dismiss action is visible while the app is closed. If Android requests exact-alarm access, use the settings button on the Alarms or Timer screen. Scheduled alarms and active timers are restored after an ordinary reboot and unlock. The local clock and alarms follow the device time zone.

## Build and source

This is a focused adaptation of Razeeman's **Simple Time Tracker 1.61**. The tracking core uses its Record, RunningRecord, RecordBase, MultitaskRecord, Range and RangeMapper classes and common domain extensions. The native clock screens, worker/job profiles, administrative controls, local database and MODE payroll integration are specific to Time. The upstream source is at https://github.com/Razeeman/Android-SimpleTimeTracker. The included GPLv3 license applies to this derivative.

Use JDK 17 or 21 and Android SDK Platform 35. From the project directory run `./gradlew assembleRelease`. Sign the resulting release APK using your Android release keystore. The signing material stays outside the project.
