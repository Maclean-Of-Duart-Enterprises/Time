package com.macleanofduartenterprises.time

import org.json.JSONObject
import org.json.JSONArray
import org.json.JSONTokener
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.util.Base64

data class DisplayUpdate(val theme:String?,val face:String?,val hours:String?,val seconds:Boolean?){
    fun applyTo(old:Appearance)=Appearance(theme?:old.theme,face?:old.face,hours?:old.hourFormat,seconds?:old.seconds)
}
data class EmployeeDocument(val name:String,val mime:String,val bytes:ByteArray)
data class SetupWorker(val profile:Person,val files:List<EmployeeDocument>)
data class SetupAddress(val jobCode:String?,val employee:String?,val business:String,val value:String)
class SetupSignature(private val payload:ByteArray,private val signature:ByteArray){
    companion object {
        fun publicKey(text:String)=KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(
            Base64.getDecoder().decode(text.replace("-----BEGIN PUBLIC KEY-----","").replace("-----END PUBLIC KEY-----","").filterNot(Char::isWhitespace))))
    }
    fun verify(trusted:String?){
        require(!trusted.isNullOrBlank()){"Add the sender’s public key in Settings → Admin panel first."}
        val verifier=Signature.getInstance("SHA256withECDSA")
        verifier.initVerify(publicKey(trusted));verifier.update(payload)
        require(verifier.verify(signature)){"The setup file signature does not match the trusted sender."}
    }
}
data class EmployeeSetup(val workers:List<SetupWorker>,val jobs:List<ImportedJob>,val addresses:List<SetupAddress>,
                         val settings:DisplayUpdate?,val password:String?,val signature:SetupSignature?){
    fun summary()=listOfNotNull(
        workers.takeIf{it.isNotEmpty()}?.let{"Workers: "+it.take(5).joinToString{w->w.profile.name}+if(it.size>5)" (and "+(it.size-5)+" more)" else ""},
        jobs.takeIf{it.isNotEmpty()}?.let{"Jobs: "+it.take(4).joinToString{j->j.job.caption}+if(it.size>4)" (and "+(it.size-4)+" more)" else ""},
        addresses.takeIf{it.isNotEmpty()}?.let{"Address updates: "+it.size},
        workers.sumOf{it.files.size}.takeIf{it>0}?.let{"Employee files: "+it},
        settings?.let{s->listOfNotNull(s.theme?.let{"Theme: "+it},s.face?.let{"Clock: "+it},
            s.hours?.let{"Hour format: "+it},s.seconds?.let{if(it)"Show seconds" else "Hide seconds"}).joinToString(" · ")}
    ).joinToString("\n")
}
private fun JSONObject.only(vararg keys:String){
    require(keys().asSequence().all{it in keys}){"Unrecognized field in setup file. Check the employee setup template."}
}
private fun JSONObject.scalar(key:String):String{
    val value=get(key)
    require(value is String || value is Number || value is Boolean){"Use a text or numeric value for "+key+"."}
    return value.toString()
}
private fun JSONObject.first(vararg keys:String)=keys.firstOrNull(::has)?.let(::scalar)
private fun JSONObject.items(key:String):List<JSONObject>{
    if(!has(key))return emptyList()
    val a=getJSONArray(key)
    require(a.length()<=1000){"Too many entries in "+key+"."}
    return (0 until a.length()).map(a::getJSONObject)
}
private fun JSONObject.fields():Map<String,String>{
    if(!has("fields"))return emptyMap()
    val fields=getJSONObject("fields")
    return fields.keys().asSequence().associateWith(fields::scalar)
}
object SetupCodec{
    const val MAX_BYTES=16*1024*1024
    private fun json(bytes:ByteArray):JSONObject{
        val text=bytes.toString(Charsets.UTF_8).removePrefix("\uFEFF")
        var depth=0;var quoted=false;var escape=false
        for(ch in text){
            if(quoted){
                if(escape)escape=false else if(ch=='\\')escape=true else if(ch=='"')quoted=false
            }else when(ch){
                '"'->quoted=true
                '{','['->{depth++;require(depth<=32){"Setup data is nested too deeply."}}
                '}',']'->{depth--;require(depth>=0){"Invalid JSON structure."}}
                '\'','#','/'->error("Choose a JSON data file.")
            }
        }
        require(depth==0 && !quoted){"Incomplete JSON file."}
        val tokenizer=JSONTokener(text)
        val result=tokenizer.nextValue()
        require(result is JSONObject && tokenizer.nextClean()=='\u0000'){"Choose one JSON setup object."}
        return result
    }
    fun withPassword(bytes:ByteArray,password:String):ByteArray{
        require(password.matches(Regex("[0-9]{6,12}"))){"Use the existing 6–12 digit admin PIN from the employee’s device."}
        val source=json(bytes)
        require(!source.has("signature") && !source.has("payload")){"Choose an unsigned setup file."}
        val root=if(source.has("id") && source.has("name") && source.has("profile"))
            JSONObject().put("format","time.setup.v1").put("worker",source) else source
        val output=root.put("admin_password",password).toString().toByteArray(Charsets.UTF_8)
        read(output)
        return output
    }
    fun read(bytes:ByteArray):EmployeeSetup{
        require(bytes.size in 1..MAX_BYTES){"Setup files must be at most 16 MiB."}
        val outer=json(bytes)
        val signed=outer.has("signature") || outer.has("payload")
        val proof:SetupSignature?
        val root:JSONObject
        if(signed){
            outer.only("format","payload","signature")
            require(outer.getString("format")=="time.signed.v1"){"Unknown signature format."}
            val payload=Base64.getDecoder().decode(outer.getString("payload"))
            proof=SetupSignature(payload,Base64.getDecoder().decode(outer.getString("signature")))
            root=json(payload)
        }else{root=outer;proof=null}
        val directWorker=root.has("name") && root.has("id") && root.has("profile")
        if(!directWorker)root.only("format","admin_password","settings","worker","employees","jobs","addresses")
        if(root.has("format"))require(root.getString("format")=="time.setup.v1"){"Unsupported setup version."}
        val workers=(if(directWorker)listOf(root) else listOfNotNull(if(root.has("worker"))root.getJSONObject("worker")else null)+root.items("employees")).map(::worker)
        val jobs=root.items("jobs").map{j->
            j.only("job_name","name","summary","job_code","job_number","job_site_address","address","multiplier","fields")
            val fields=j.fields()+(j.first("job_site_address","address")?.let{mapOf("Site address" to it)}?:emptyMap())
            ImportedJob(Job(name=j.first("job_name","name","summary").orEmpty().trim(),code=j.first("job_code","job_number").orEmpty().trim(),
                fields=canonicalJobFields(fields),factor=j.first("multiplier")?:"1").checked(),j.has("multiplier"))
        }
        val addresses=root.items("addresses").map{a->
            a.only("job_code","employee_id","business_profile_id","address")
            val job=a.first("job_code");val emp=a.first("employee_id")
            require((job==null)!=(emp==null) && (job?:emp).orEmpty().isNotBlank()){"Each address needs a job code or employee ID."}
            SetupAddress(job,emp,a.first("business_profile_id").orEmpty(),a.scalar("address").also{require(it.length<=10000)})
        }
        val settings=if(root.has("settings"))root.getJSONObject("settings").let{s->
            s.only("theme","clock_face","hour_format","show_seconds")
            require(s.length()>0){"Include at least one setting."}
            val seconds=if(s.has("show_seconds"))s.get("show_seconds").also{require(it is Boolean){"show_seconds must be true or false."}} as Boolean else null
            DisplayUpdate(s.first("theme"),s.first("clock_face"),s.first("hour_format"),seconds).also{it.applyTo(Appearance())}
        }else null
        require(workers.isNotEmpty() || jobs.isNotEmpty() || addresses.isNotEmpty() || settings!=null){"No employee setup data found."}
        val password=root.first("admin_password")
        require(password==null || password.matches(Regex("[0-9]{6,12}"))){"The admin PIN must contain 6–12 digits."}
        require(proof==null || password==null){"Omit the admin PIN from signed files."}
        return EmployeeSetup(workers,jobs,addresses,settings,password,proof)
    }
    private fun worker(w:JSONObject):SetupWorker{
        w.only("name","employee_name","employee_id","id","business_profile_id","profile","fields","files","phone","email","address","kind","notes","cadence","anchor","archived","pay")
        val fields=w.fields().toMutableMap()
        for(key in listOf("phone","email","address","kind","notes"))if(w.has(key))fields[key.replaceFirstChar{it.uppercase()}]=w.scalar(key)
        val profile=Person(name=w.first("name","employee_name").orEmpty().trim(),employee=w.first("employee_id","id").orEmpty(),
            business=w.first("business_profile_id","profile").orEmpty(),fields=fields).checked()
        val files=w.items("files").map{f->
            f.only("name","mime","data_base64")
            val name=f.scalar("name")
            require(name.isNotBlank() && name.length<=160 && name.none{it=='/' || it=='\\' || it.isISOControl()} && name !in setOf(".","..")){"Invalid employee filename."}
            val mime=f.first("mime")?:"application/octet-stream"
            require(mime.matches(Regex("[a-zA-Z0-9.+-]+/[a-zA-Z0-9.+-]+"))){"Invalid file type."}
            EmployeeDocument(name,mime,Base64.getDecoder().decode(f.getString("data_base64")))
        }
        require(files.distinctBy{it.name}.size==files.size){"Duplicate filename for "+profile.name}
        return SetupWorker(profile,files)
    }
}
