import com.macleanofduartenterprises.time.*
import org.json.JSONObject
import java.io.File
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.util.Base64
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

fun main(args:Array<String>){
    val bytes=File(args.single()).readBytes()
    val setup=SetupCodec.read(bytes)
    val worker=setup.workers.single()
    check(worker.profile.employee=="17" && worker.profile.business=="1")
    check(String(worker.files.single().bytes).startsWith("Check in with"))
    check(setup.jobs.single().job.address.contains("Lebanon"))
    val legacy=JobCsv.parse("job_name,Site address,Customer\nSample,123 Main Street,Owner").single().job
    check(legacy.address=="123 Main Street" && legacy.otherFields==mapOf("Customer" to "Owner"))
    check(JobCsv.parse(JobCsv.export(listOf(legacy))).single().job==legacy)
    val a=setup.settings!!.applyTo(Appearance());check(a.face=="both" && !a.seconds)
    check(LocalTime.of(15,25,10).format(DateTimeFormatter.ofPattern(a.pattern(true),Locale.US))=="3:25 PM")
    check(a.copy(hourFormat="24",seconds=true).pattern(false)=="HH:mm:ss")
    check(Appearance().pattern(true)=="HH:mm:ss" && Appearance().pattern(false)=="h:mm:ss a")
    check(a.night(32) && !a.night(16) && a.copy(theme="dark").night(16) && !a.copy(theme="light").night(32))
    val sender=KeyPairGenerator.getInstance("EC").apply{initialize(ECGenParameterSpec("secp256r1"))}.generateKeyPair()
    val signature=Signature.getInstance("SHA256withECDSA").run{initSign(sender.private);update(bytes);sign()}
    fun encoded(value:ByteArray)=Base64.getEncoder().encodeToString(value)
    fun envelope(payload:ByteArray)=JSONObject().put("format","time.signed.v1").put("payload",encoded(payload)).put("signature",encoded(signature)).toString().toByteArray()
    val key=encoded(sender.public.encoded)
    SetupCodec.read(envelope(bytes)).signature!!.verify(key)
    fun mustFail(test:()->Unit){check(runCatching(test).isFailure)}
    mustFail{SetupCodec.read(envelope(bytes+" ".toByteArray())).signature!!.verify(key)}
    mustFail{SetupCodec.read(envelope(bytes)).signature!!.verify(null)}
    val direct=SetupCodec.read("""{"id":8,"profile":3,"name":"MODE Worker","address":"123 Maple","pay":{},"phone":"555-0102"}""".toByteArray())
    check(direct.workers.single().profile.fields["Phone"]=="555-0102")
    check(SetupCodec.read("""{"settings":{"theme":"light"},"admin_password":"123456"}""".toByteArray()).password=="123456")
    listOf("""{"settings":{"theme":"bright"}}""","""{"settings":{"show_seconds":"true"}}""",
        """{"admin_controls":false,"settings":{"theme":"dark"}}""","""{"settings":{"theme":"dark"}} extra""",
        """{"addresses":[{"job_code":"A","employee_id":"2","address":"B"}]}""",
        """{"settings":{"theme":"dark"},"admin_password":"12"}""","[".repeat(100)+"0"+"]".repeat(100))
        .forEach{mustFail{SetupCodec.read(it.toByteArray())}}
    println("Passed example, MODE identity mapping, attachments, signature and tamper checks, strict settings validation, legacy address CSV and clock formats.")
}
