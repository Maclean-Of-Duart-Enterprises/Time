# Employee setup files

Open **Settings → Import employee setup JSON** and select the file. Time applies an authorized file immediately and selects the worker on the Timecard tab when it contains one employee. Admin stays locked. Employee attachments are accessible under **Profiles → Workers**.

## Include the recipient's admin PIN

On the administrator’s phone, open **Settings → Admin panel → Add admin PIN to setup JSON**. Choose the MODE export, enter and confirm the existing PIN for the receiving phone, and save the authorized copy. Send that copy to the employee. A producer can also include the PIN directly as the top-level JSON string `admin_password`. Anyone with this copy can read and reuse the PIN. A valid PIN or trusted signature permits immediate import. An unsigned file without the PIN prompts once per import when controls are enabled.

## Send a file without sharing the admin PIN

1. On the administrator’s phone, open **Settings → Admin panel → Show this device’s sender key** and copy the public key.
2. On each employee phone, open **Settings → Admin panel → Trust setup sender**, paste the administrator’s public key, and turn on admin controls if needed. Compare the displayed key fingerprint or distribute the public key directly during enrollment. The private signing key stays in Android Keystore on the administrator’s phone.
3. Prepare a JSON file for that employee using the example in this project. On the administrator’s phone use **Settings → Admin panel → Sign employee setup file**, review its contents and save the signed JSON. Send the signed file to that employee.
4. The employee imports it from Settings. Time verifies the signature using the enrolled key and applies the update while Admin stays locked. A changed file or a different sender fails verification. To revoke a sender, remove its key in Admin. After replacing an administrator phone or reinstalling its app, enroll the new sender key.

## JSON format for MODE Handyman

Start from **examples/Time-employee-setup-example.json**. Include only the sections you want to change. Use UTF-8 JSON data. The file limit is 16 MiB including any Base64 encoding. Attachments and profiles stay on the recipient’s device until explicitly saved or exported. Signed files establish the sender and content integrity. Anyone with the file can read its contents.

| Field | Accepted values or behavior |
| --- | --- |
| `format` | `time.setup.v1` |
| `settings.theme` | `automatic`, `light`, `dark` |
| `settings.clock_face` | `analog`, `digital`, `both` |
| `settings.hour_format` | `system`, `12`, `24` |
| `settings.show_seconds` | JSON boolean |
| `employees` | Array of workers. Provide a name and optional numeric employee and business profile IDs. A single `worker` object is also accepted. |
| `jobs` | Array of jobs. Use `job_name` and optionally `job_code`, `job_site_address`, `fields` and `multiplier`. MODE's `summary` and `job_number` aliases are supported. |
| `addresses` | Array of changes to an existing or included worker or job, e.g. `{"job_code":"DEMO-101","address":"123 Main Street"}` or `{"employee_id":"17","business_profile_id":"1","address":"123 Main Street"}`. An empty address clears it. |
| `fields` | Custom label/value object on the worker or job. A setup worker receives the profile fields in its JSON. Job updates retain omitted custom labels. |
| `files` | Per-worker array of `name`, optional MIME type `mime`, and standard Base64 `data_base64`. Reimporting the same filename for the same worker replaces its contents. |

A MODE 2.2.0 payroll worker object from `PayrollCodec.worker` can be imported directly, or under `worker`. The importer maps `id`, `profile`, `name`, `kind`, `phone`, `email`, `address` and `notes`. Payroll rates, taxes and paystubs stay in MODE. Setup files can come from the employee setup exporter in MODE Handyman.

Time checks the MODE identity and matches names regardless of capitalization, surrounding spaces or repeated spacing. A same-name manual worker adopts the supplied MODE identifiers. Reimporting consolidates matching legacy duplicates, moves their shifts and attachments to one profile, and replaces the profile details with the JSON values. If both copies have a running shift, clock out one before reimporting. Distinct known businesses remain separate. Jobs match by code, or by name when a code is absent. A file that fails validation or cannot resolve an address rolls back the whole import. Existing shifts and alarms are independent of setup imports.

A MODE exporter can sign files directly. Sign the exact UTF-8 setup bytes using ECDSA P-256 and SHA-256, encoding the signature in ASN.1 DER form. Send a JSON object containing `format: "time.signed.v1"`, `payload` (standard Base64 of the original bytes) and `signature` (standard Base64 of the signature). Enroll the producer’s X.509 SubjectPublicKeyInfo public key using **Trust setup sender**. Each device trusts one sender at a time.
